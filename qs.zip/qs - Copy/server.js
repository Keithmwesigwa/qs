const express = require('express');
const mysql = require('mysql2/promise');
const cloudinary = require('cloudinary').v2;
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Cloudinary configuration
cloudinary.config({
  cloud_name: "dpgf8pzuo",
  api_key: "385877743365342",
  api_secret: "JtqBAwRyAxzuD379sH5PR1NM8vM"
});

// MySQL connection configuration
const dbConfig = {
  host: 'freedbeccom-nexora.h.aivencloud.com',
  user: 'avnadmin',
  port: 14673,
  password: 'AVNS_rG5nsa4PxWCk-zHTBhl',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
};

// MySQL connection pool (will be initialized after database is created)
let pool;

// Initialize database and create pool
async function initDatabase() {
  try {
    // First, create a connection without specifying the database
    const tempConnection = await mysql.createConnection({
      host: dbConfig.host,
      user: dbConfig.user,
      port: dbConfig.port,
      password: dbConfig.password
    });
    
    // Create database if not exists
    await tempConnection.query('CREATE DATABASE IF NOT EXISTS photobook_db');
    await tempConnection.end();
    
    // Now create the pool with the database
    pool = mysql.createPool({
      ...dbConfig,
      database: 'photobook_db'
    });
    
    // Get connection from pool and create tables
    const connection = await pool.getConnection();
    
    // Create users table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    // Create books table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS books (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        title VARCHAR(255) NOT NULL,
        template VARCHAR(50) NOT NULL,
        mode ENUM('smart', 'manual') NOT NULL,
        page_count INT DEFAULT 25,
        status ENUM('draft', 'completed') DEFAULT 'draft',
        pdf_url VARCHAR(500),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);
    
    // Add page_count column if it doesn't exist (for existing databases)
    try {
      await connection.query('ALTER TABLE books ADD COLUMN page_count INT DEFAULT 25');
    } catch (error) {
      // Column already exists, ignore
    }
    
    // Create pages table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS pages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        book_id INT NOT NULL,
        page_number INT NOT NULL,
        layout_type VARCHAR(50) NOT NULL,
        content JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
        UNIQUE KEY unique_page (book_id, page_number)
      )
    `);
    
    // Create images table
    await connection.query(`
      CREATE TABLE IF NOT EXISTS images (
        id INT AUTO_INCREMENT PRIMARY KEY,
        book_id INT,
        user_id INT NOT NULL,
        cloudinary_id VARCHAR(255) NOT NULL,
        cloudinary_url VARCHAR(500) NOT NULL,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE SET NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `);
    
    connection.release();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization error:', error);
    // If database creation fails, try to continue with pool anyway
    // (database might already exist or be created manually)
    pool = mysql.createPool({
      ...dbConfig,
      database: 'photobook_db'
    });
  }
}

// Routes (will be set up after database initialization)
let authRoutes, bookRoutes, uploadRoutes, pdfRoutes;

function setupRoutes() {
  authRoutes = require('./routes/auth');
  bookRoutes = require('./routes/books');
  uploadRoutes = require('./routes/upload');
  pdfRoutes = require('./routes/pdf');

  app.use('/api/auth', authRoutes(pool));
  app.use('/api/books', bookRoutes(pool, io));
  app.use('/api/upload', uploadRoutes(pool, cloudinary));
  app.use('/api/pdf', pdfRoutes(pool, cloudinary));
}

// Socket.io for real-time updates
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);
  
  socket.on('join-book', (bookId) => {
    socket.join(`book-${bookId}`);
  });
  
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Serve frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

const PORT = process.env.PORT || 3000;

// Initialize database and start server
async function startServer() {
  try {
    await initDatabase();
    setupRoutes();
    server.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

