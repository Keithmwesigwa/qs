// Wait for api.js to load and DOM to be ready
function checkAuth() {
    if (typeof window === 'undefined') {
        // Not in browser environment, wait
        setTimeout(checkAuth, 100);
        return;
    }
    
    if (typeof getToken === 'undefined') {
        setTimeout(checkAuth, 100);
        return;
    }
    
    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                if (!getToken()) {
                    window.location.href = 'login.html';
                    return;
                }
                initializeSmartMode();
            });
        } else {
            if (!getToken()) {
                window.location.href = 'login.html';
                return;
            }
            initializeSmartMode();
        }
    }
}

// Get book ID from URL
let bookId = null;
if (typeof window !== 'undefined' && typeof URLSearchParams !== 'undefined') {
    const urlParams = new URLSearchParams(window.location.search);
    bookId = urlParams.get('bookId');
}

function initializeSmartMode() {
    if (!bookId) {
        if (typeof window !== 'undefined') {
            window.location.href = 'dashboard.html';
        }
        return;
    }
    
    // Wait for DOM
    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                setupSmartMode();
            });
        } else {
            setupSmartMode();
        }
    }
}

let book = null;
let uploadedImages = [];

function setupSmartMode() {
    // Load book data
    loadBook();
    
    // Setup event listeners
    setupEventListeners();
}

// Load book data
async function loadBook() {
    try {
        const response = await booksAPI.getOne(bookId);
        book = response.book;
        
        // Check if book has already been generated (has pages with images)
        const hasGeneratedContent = book.pages && book.pages.some(page => {
            try {
                const content = typeof page.content === 'string' 
                    ? JSON.parse(page.content) 
                    : page.content || {};
                return content.images && content.images.length > 0;
            } catch (e) {
                return false;
            }
        });
        
        // If book already has generated content, redirect to manual studio for editing
        if (hasGeneratedContent) {
            window.location.href = `manual-mode.html?bookId=${bookId}`;
            return;
        }
        
        document.getElementById('bookTitle').textContent = book.title;
        document.getElementById('bookTemplate').textContent = `Template: ${book.template}`;
    } catch (error) {
        console.error('Failed to load book:', error);
        alert('Failed to load book');
        window.location.href = 'dashboard.html';
    }
}

// Setup event listeners
function setupEventListeners() {
    const uploadArea = document.getElementById('uploadArea');
    const imageInput = document.getElementById('imageInput');
    
    if (uploadArea && imageInput) {
        uploadArea.addEventListener('click', () => {
            imageInput.click();
        });

        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            handleFiles(e.dataTransfer.files);
        });

        imageInput.addEventListener('change', (e) => {
            handleFiles(e.target.files);
        });
    }
    
    const generateBtn = document.getElementById('generateBookBtn');
    if (generateBtn) {
        generateBtn.addEventListener('click', generateBook);
    }
    
}

// Handle file uploads
async function handleFiles(files) {
    const imageFiles = Array.from(files).filter(file => file.type.startsWith('image/'));
    
    if (imageFiles.length === 0) {
        alert('Please select image files');
        return;
    }

    try {
        const response = await uploadAPI.uploadImages(imageFiles);
        uploadedImages = [...uploadedImages, ...response.images];
        renderUploadedImages();
        document.getElementById('generateBookBtn').style.display = 'block';
    } catch (error) {
        alert('Failed to upload images: ' + error.message);
    }
}

// Render uploaded images
function renderUploadedImages() {
    const container = document.getElementById('uploadedImages');
    container.innerHTML = uploadedImages.map((img, index) => `
        <div class="uploaded-image">
            <img src="${img.url}" alt="Uploaded image ${index + 1}">
            <button class="remove-btn" onclick="removeImage(${index})">×</button>
        </div>
    `).join('');
}

// Remove image
window.removeImage = function(index) {
    uploadedImages.splice(index, 1);
    renderUploadedImages();
    if (uploadedImages.length === 0) {
        document.getElementById('generateBookBtn').style.display = 'none';
    }
};

// Generate book algorithm
async function generateBook() {
    if (uploadedImages.length < 10) {
        alert('Please upload at least 10 images for best results');
        return;
    }

    // Show loading state
    const generateBtn = document.getElementById('generateBookBtn');
    if (generateBtn) {
        generateBtn.disabled = true;
        generateBtn.textContent = 'Generating... Please wait';
    }

    try {
        // Get page count from book
        const pageCount = book.page_count || 25;
        
        // AI Algorithm to intelligently distribute images across pages
        // Create varied layouts for visual interest
        const layoutSequence = [];
        const totalImages = uploadedImages.length;
        const imagesPerPage = {
            'single': 1,
            'double': 2,
            'triple': 3,
            'quad': 4
        };

        // Calculate optimal layout distribution
        // First and last pages are often single or double for impact
        // Middle pages use more varied layouts
        for (let i = 1; i <= pageCount; i++) {
            if (i === 1 || i === pageCount) {
                // First and last pages: single or double for emphasis
                layoutSequence.push(Math.random() > 0.5 ? 'single' : 'double');
            } else if (i % 5 === 0) {
                // Every 5th page: quad layout for variety
                layoutSequence.push('quad');
            } else if (i % 3 === 0) {
                // Every 3rd page: triple layout
                layoutSequence.push('triple');
            } else if (i % 2 === 0) {
                // Even pages: double
                layoutSequence.push('double');
            } else {
                // Odd pages: single
                layoutSequence.push('single');
            }
        }

        // Distribute images across pages
        let imageIndex = 0;
        
        for (let pageNum = 1; pageNum <= pageCount; pageNum++) {
            const layout = layoutSequence[pageNum - 1];
            const imagesNeeded = imagesPerPage[layout];
            const pageImages = [];

            // Add images for this page
            for (let i = 0; i < imagesNeeded && imageIndex < totalImages; i++) {
                const img = uploadedImages[imageIndex];
                pageImages.push({
                    url: img.url || img.cloudinary_url || null,
                    cloudinary_url: img.cloudinary_url || img.url || null,
                    cloudinary_id: img.cloudinary_id || img.id || null
                });
                imageIndex++;
            }

            // If we run out of images, intelligently reuse best images
            // Reuse images from the beginning (often best/important photos)
            while (pageImages.length < imagesNeeded && totalImages > 0) {
                const reuseIndex = (totalImages - pageImages.length - 1) % totalImages;
                const imageToReuse = uploadedImages[reuseIndex];
                pageImages.push({
                    url: imageToReuse.url || imageToReuse.cloudinary_url || null,
                    cloudinary_url: imageToReuse.cloudinary_url || imageToReuse.url || null,
                    cloudinary_id: imageToReuse.cloudinary_id || imageToReuse.id || null
                });
            }

            const content = {
                images: pageImages,
                texts: []
            };

            // Update page in database
            await booksAPI.updatePage(bookId, pageNum, layout, content);
        }

        // Update book status
        await booksAPI.update(bookId, { status: 'draft' });
        
        // Redirect to manual editing studio where user can make adjustments
        alert('Photo book generated successfully! Opening in editing studio...');
        window.location.href = `manual-mode.html?bookId=${bookId}`;
    } catch (error) {
        console.error('Failed to generate book:', error);
        alert('Failed to generate book: ' + error.message);
        
        // Re-enable generate button on error
        const generateBtn = document.getElementById('generateBookBtn');
        if (generateBtn) {
            generateBtn.disabled = false;
            generateBtn.textContent = 'Generate Photo Book';
        }
    }
}


// Initialize
checkAuth();

