// Wait for api.js to load and DOM to be ready
function checkAuth() {
    if (typeof window === 'undefined') {
        // Not in browser environment, wait
        setTimeout(checkAuth, 100);
        return;
    }
    
    if (typeof getToken === 'undefined') {
        setTimeout(checkAuth, 100);
        return;
    }
    
    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                if (!getToken()) {
                    window.location.href = 'login.html';
                    return;
                }
                initializeManualMode();
            });
        } else {
            if (!getToken()) {
                window.location.href = 'login.html';
                return;
            }
            initializeManualMode();
        }
    }
}

// Get book ID from URL (will be set after api.js loads)
let bookId = null;
if (typeof window !== 'undefined' && typeof URLSearchParams !== 'undefined') {
    const urlParams = new URLSearchParams(window.location.search);
    bookId = urlParams.get('bookId');
}

let book = null;
let pages = [];
let currentPageNumber = 1;
let selectedPageNumber = null; // Currently selected page for editing (can be left or right)
let currentLayout = 'single';
let myImages = []; // Global array to store user's images

// Expose myImages to window so manual-editor-ui.js can access it
if (typeof window !== 'undefined') {
    Object.defineProperty(window, 'myImagesArray', {
        get: function() { return myImages; },
        enumerable: true,
        configurable: true
    });
    
    // Debug function to check state
    window.debugImages = function() {
        console.log('=== DEBUG IMAGES ===');
        console.log('myImages array:', myImages);
        console.log('myImages length:', myImages.length);
        console.log('window.myImagesArray:', window.myImagesArray);
        const container = document.getElementById('myImages');
        console.log('Container exists:', !!container);
        console.log('Container children:', container ? container.children.length : 0);
        console.log('Container innerHTML length:', container ? container.innerHTML.length : 0);
        console.log('===================');
    };
}

let selectedImage = null;
let viewMode = 'spread'; // 'spread' or 'single'
let draggedTextElement = null;
let dragOffset = { x: 0, y: 0 };

// Load book data
async function loadBook() {
    try {
        const response = await booksAPI.getOne(bookId);
        book = response.book;
        pages = book.pages || [];
        
        // Update book title in header
        const bookTitleEl = document.getElementById('bookTitle');
        if (bookTitleEl) {
            bookTitleEl.textContent = book.title;
        }
        
        // Ensure we have all pages for the book
        // Total should be 27: 1 front cover + 25 content pages + 1 back cover
        let totalPages = book.page_count || 27;
        
        // If book was created with old system (25 pages), update to 27 (25 content + 2 covers)
        if (totalPages === 25) {
            totalPages = 27;
            // Update book in database
            try {
                await booksAPI.update(bookId, { page_count: 27 });
                book.page_count = 27;
                console.log('Updated book page_count to 27 (25 content + 2 covers)');
            } catch (error) {
                console.error('Failed to update page count:', error);
            }
        }
        
        if (pages.length < totalPages) {
            // Create missing pages
            console.log(`Creating ${totalPages - pages.length} missing pages...`);
            for (let i = pages.length + 1; i <= totalPages; i++) {
                try {
                    await createPage(i);
                } catch (error) {
                    console.error(`Failed to create page ${i}:`, error);
                }
            }
            // Reload to get all pages
            const reloadResponse = await booksAPI.getOne(bookId);
            book = reloadResponse.book;
            pages = reloadResponse.book.pages || [];
        }
        
        console.log(`Loaded ${pages.length} pages for book with ${totalPages} total pages (25 content + 2 covers)`);
        
        // Ensure we have exactly 27 pages (1 cover + 25 content + 1 cover)
        if (pages.length < 27) {
            console.log(`Creating missing pages to reach 27 total...`);
            for (let i = pages.length + 1; i <= 27; i++) {
                try {
                    await createPage(i);
                } catch (error) {
                    console.error(`Failed to create page ${i}:`, error);
                }
            }
            // Reload to get all pages
            const reloadResponse = await booksAPI.getOne(bookId);
            book = reloadResponse.book;
            pages = reloadResponse.book.pages || [];
        }
        
        currentPageNumber = 1;
        
        // Render pages list first
        renderPagesList();
        
        // Then load the spread
        loadSpread(currentPageNumber);
        
        // Load images
        loadMyImages();
    } catch (error) {
        console.error('Failed to load book:', error);
        alert('Failed to load book: ' + error.message);
        window.location.href = 'dashboard.html';
    }
}

// Load my images
async function loadMyImages() {
    try {
        console.log('=== loadMyImages START ===');
        console.log('Loading images from server...');
        
        const response = await uploadAPI.getImages();
        console.log('Raw server response:', response);
        console.log('Response type:', typeof response);
        console.log('Response.images:', response?.images);
        
        if (response && response.images) {
            const imagesArray = Array.isArray(response.images) ? response.images : [];
            console.log('Got', imagesArray.length, 'images from server');
            
            // Process and validate images
            myImages = imagesArray.map(img => {
                // Ensure we have both cloudinary_url and url for compatibility
                const url = img.cloudinary_url || img.url;
                return {
                    id: img.id,
                    cloudinary_id: img.cloudinary_id,
                    cloudinary_url: url,
                    url: url
                };
            }).filter(img => {
                const hasUrl = img.cloudinary_url || img.url;
                if (!hasUrl) {
                    console.warn('Filtering image without URL:', img);
                }
                return hasUrl;
            });
            
            console.log('Processed', myImages.length, 'valid images');
            if (myImages.length > 0) {
                console.log('First image:', myImages[0]);
            }
        } else {
            console.warn('Unexpected response format. Response:', response);
            myImages = [];
        }
        
        // Render immediately - use local function, not window.renderMyImages
        console.log('Calling renderMyImages with', myImages.length, 'images');
        console.log('myImages array before render:', myImages);
        
        // Call the local renderMyImages function directly
        renderMyImagesLocal();
        
        console.log('=== loadMyImages END ===');
    } catch (error) {
        console.error('ERROR in loadMyImages:', error);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
        myImages = [];
        renderMyImagesLocal();
    }
}

// Upload image file
async function uploadImageFile(file) {
    try {
        console.log('=== uploadImageFile START ===');
        console.log('Uploading file:', file.name, 'Size:', file.size);
        
        const response = await uploadAPI.uploadImage(file);
        console.log('Upload response:', JSON.stringify(response, null, 2));
        
        if (response && response.image) {
            console.log('Upload successful. Image ID:', response.image.id);
            console.log('Image URL:', response.image.url);
            
            // Immediately add the uploaded image to the array for instant display
            const newImage = {
                id: response.image.id,
                cloudinary_id: response.image.cloudinary_id,
                cloudinary_url: response.image.url, // API returns 'url', map to 'cloudinary_url'
                url: response.image.url // Also keep 'url' for compatibility
            };
            
            console.log('New image object:', newImage);
            
            // Check if image already exists (avoid duplicates)
            const exists = myImages.some(img => 
                (img.id && img.id === newImage.id) || 
                (img.cloudinary_id && img.cloudinary_id === newImage.cloudinary_id)
            );
            
            if (!exists) {
                myImages.unshift(newImage); // Add to beginning
                console.log('Added image to array. Total images now:', myImages.length);
                console.log('myImages array:', myImages);
                
                // Render immediately
                renderMyImagesLocal();
            } else {
                console.log('Image already exists, skipping duplicate');
            }
            
            // Show the images panel
            const imagesPanel = document.getElementById('imagesPanel');
            const imagesTab = document.querySelector('.tool-tab[data-tool="images"]');
            if (imagesPanel && imagesTab) {
                // Switch to images tab
                document.querySelectorAll('.tool-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.tool-panel').forEach(p => p.classList.remove('active'));
                imagesTab.classList.add('active');
                imagesPanel.classList.add('active');
                console.log('Switched to images panel');
                
                // Render again after panel is visible
                setTimeout(() => {
                    renderMyImagesLocal();
                }, 100);
            }
            
            // Reload images from server to ensure consistency (this will replace with server data)
            // This ensures we get the exact format from the database
            setTimeout(async () => {
                await loadMyImages();
            }, 500); // Small delay to ensure database has updated
            
            // Show success message
            const container = document.getElementById('myImages');
            if (container) {
                const successMsg = document.createElement('div');
                successMsg.style.cssText = 'background: #10b981; color: white; padding: 8px; border-radius: 4px; margin-bottom: 10px; text-align: center; font-size: 12px;';
                successMsg.textContent = '✓ Image uploaded successfully!';
                container.insertBefore(successMsg, container.firstChild);
                setTimeout(() => {
                    if (successMsg.parentNode) {
                        successMsg.remove();
                    }
                }, 3000);
            }
        } else {
            console.error('Unexpected upload response format:', response);
            throw new Error('Upload response missing image data');
        }
        
        console.log('=== uploadImageFile END ===');
        return response;
    } catch (error) {
        console.error('Failed to upload image:', error);
        console.error('Error details:', error.message, error.stack);
        alert('Failed to upload image: ' + (error.message || 'Unknown error'));
        throw error;
    }
}

// Export handlers for UI
if (typeof window !== 'undefined') {
    window.loadMyImagesHandler = loadMyImages;
    window.loadMyImages = loadMyImages;
    window.uploadImageFile = uploadImageFile;
    window.addImageToLibrary = function(image) {
        myImages.push(image);
        renderMyImagesLocal();
    };
    // Expose function to set selectedImage from other scripts
    window.setSelectedImage = function(img) {
        selectedImage = img;
        console.log('selectedImage set via window.setSelectedImage:', selectedImage);
    };
    // Make sure changePageLayout is available early
    // (it's defined later but we ensure it's accessible)
}

// Render my images - SIMPLIFIED AND ROBUST VERSION
// This is the LOCAL function that uses the myImages global array
function renderMyImagesLocal() {
    console.log('=== renderMyImages START ===');
    console.log('myImages count:', myImages?.length || 0);
    console.log('myImages:', myImages);
    
    // Try to find container, retry if not found
    let container = document.getElementById('myImages');
    if (!container) {
        console.warn('Container not found, retrying...');
        setTimeout(() => {
            container = document.getElementById('myImages');
            if (container) {
                renderMyImagesLocal();
            } else {
                console.error('Container still not found after retry');
            }
        }, 200);
        return;
    }
    
    console.log('Container found, proceeding to render');
    
    // Clear any existing content
    container.innerHTML = '';
    
    // Check if we have images
    if (!myImages || !Array.isArray(myImages) || myImages.length === 0) {
        console.log('No images, showing empty message');
        container.innerHTML = '<p style="text-align: center; color: #9ca3af; padding: 20px;">No images uploaded yet</p>';
        return;
    }
    
    console.log('Rendering', myImages.length, 'images');
    
    // Render each image
    myImages.forEach((img, index) => {
        // Get URL - try both fields
        const imageUrl = img.cloudinary_url || img.url;
        const imageId = img.id || img.cloudinary_id || `img-${index}`;
        
        if (!imageUrl) {
            console.warn('Skipping image without URL:', img);
            return;
        }
        
        // Validate URL
        const validUrl = String(imageUrl).trim();
        if (!validUrl || (!validUrl.startsWith('http://') && !validUrl.startsWith('https://'))) {
            console.warn('Invalid URL, skipping:', validUrl);
            return;
        }
        
        console.log(`Rendering image ${index + 1}: ${validUrl.substring(0, 50)}...`);
        
        // Create image item element
        const itemDiv = document.createElement('div');
        itemDiv.className = 'my-image-item';
        itemDiv.dataset.imageId = imageId;
        itemDiv.dataset.imageUrl = validUrl;
        
        // Create img element
        const imgEl = document.createElement('img');
        imgEl.src = validUrl;
        imgEl.alt = `Image ${index + 1}`;
        imgEl.style.cssText = 'width: 100%; height: 100%; object-fit: cover; display: block;';
        imgEl.onerror = function() {
            console.error('Image failed to load:', this.src);
            this.parentElement.style.display = 'none';
        };
        imgEl.onload = function() {
            console.log('Image loaded successfully:', this.src);
        };
        
        // Add click handler
        itemDiv.addEventListener('click', function() {
            // Remove selection from all
            document.querySelectorAll('.my-image-item').forEach(i => i.classList.remove('selected'));
            // Add selection to this
            this.classList.add('selected');
            selectedImage = {
                id: this.dataset.imageId,
                url: this.dataset.imageUrl,
                cloudinary_url: this.dataset.imageUrl
            };
            console.log('Image selected:', selectedImage);
            
            // Also set via window function for other scripts
            if (window.setSelectedImage) {
                window.setSelectedImage(selectedImage);
            }
        });
        
        // Make draggable for drag-and-drop
        itemDiv.draggable = true;
        itemDiv.style.cursor = 'grab';
        itemDiv.setAttribute('draggable', 'true');
        
        itemDiv.addEventListener('dragstart', function(e) {
            const imageData = {
                id: this.dataset.imageId,
                url: this.dataset.imageUrl,
                cloudinary_url: this.dataset.imageUrl
            };
            // Set data in multiple formats for better compatibility
            e.dataTransfer.setData('text/plain', JSON.stringify(imageData));
            e.dataTransfer.setData('application/json', JSON.stringify(imageData));
            e.dataTransfer.effectAllowed = 'copy';
            e.dataTransfer.dropEffect = 'copy';
            this.style.opacity = '0.5';
            this.style.cursor = 'grabbing';
            console.log('Drag started with image:', imageData);
        }, false);
        
        itemDiv.addEventListener('dragend', function(e) {
            this.style.opacity = '1';
            this.style.cursor = 'grab';
            // Reset all drop zones
            document.querySelectorAll('.image-slot, .page-placeholder').forEach(el => {
                el.style.background = '';
                el.style.borderColor = '';
            });
        }, false);
        
        itemDiv.appendChild(imgEl);
        container.appendChild(itemDiv);
    });
    
    console.log('Rendered', container.children.length, 'image items');
    console.log('=== renderMyImages END ===');
}

// Create page
async function createPage(pageNumber) {
    try {
        await booksAPI.updatePage(bookId, pageNumber, 'single', { images: [], texts: [] });
        pages.push({ page_number: pageNumber, layout_type: 'single', content: { images: [], texts: [] } });
        renderPagesList();
    } catch (error) {
        console.error('Failed to create page:', error);
    }
}

// Render pages list as page pairs
function renderPagesList() {
    const totalPages = book?.page_count || 27; // 27 = 1 front cover + 25 content + 1 back cover
    // Covers are separate, so actual content pages = totalPages - 2 (front cover + back cover)
    // Always ensure we have 25 content pages
    const contentPages = 25;
    
    // Update total pages count in header (show content pages only)
    const totalPagesCount = document.getElementById('totalPagesCount');
    if (totalPagesCount) {
        totalPagesCount.textContent = contentPages;
    }
    
    // Update pages list in left sidebar
    const pagesList = document.getElementById('pagesList');
    if (!pagesList) {
        console.error('pagesList element not found in DOM');
        return;
    }
    
    pagesList.innerHTML = '';
    
    // First pair: Front Cover (page 1) and Back Cover (last page = totalPages)
    const firstPair = document.createElement('div');
    firstPair.className = 'page-pair-thumbnail';
    if (currentPageNumber === 1 || currentPageNumber === totalPages) {
        firstPair.classList.add('active');
    }
    
    // Left page - Front Cover
    const frontCover = document.createElement('div');
    frontCover.className = 'page-pair-page';
    frontCover.textContent = 'Front Cover';
    frontCover.title = 'Front Cover';
    firstPair.appendChild(frontCover);
    
    // Right page - Back Cover
    const backCover = document.createElement('div');
    backCover.className = 'page-pair-page';
    backCover.textContent = 'Back Cover';
    backCover.title = 'Back Cover';
    firstPair.appendChild(backCover);
    
    firstPair.addEventListener('click', () => {
        currentPageNumber = 1;
        loadSpread(currentPageNumber);
    });
    
    pagesList.appendChild(firstPair);
    
    // Content pages: Start from page 2, display as 1-25
    // Pages 2-26 in database, but displayed as 1-25
    // Always show 25 content pages (regardless of current contentPages value)
    const targetContentPages = 25;
    for (let i = 0; i < targetContentPages; i += 2) {
        const displayPageNum = i + 1; // Display number (1-25)
        const actualPageNum = i + 2; // Actual page number in database (2-26)
        const rightDisplayNum = i + 2 <= contentPages ? i + 2 : null;
        const rightActualNum = rightDisplayNum ? rightDisplayNum + 1 : null;
        
        // Create page pair container
        const pairThumbnail = document.createElement('div');
        pairThumbnail.className = 'page-pair-thumbnail';
        
        // Mark active if this pair contains the current page
        const isActive = (currentPageNumber === actualPageNum) || 
                        (rightActualNum && currentPageNumber === rightActualNum);
        if (isActive) {
            pairThumbnail.classList.add('active');
        }
        
        // Left page
        const leftPage = document.createElement('div');
        leftPage.className = 'page-pair-page';
        leftPage.textContent = displayPageNum; // Display as 1, 3, 5, etc.
        pairThumbnail.appendChild(leftPage);
        
        // Right page (if exists)
        if (rightDisplayNum && rightActualNum) {
            const rightPage = document.createElement('div');
            rightPage.className = 'page-pair-page';
            rightPage.textContent = rightDisplayNum; // Display as 2, 4, 6, etc.
            pairThumbnail.appendChild(rightPage);
        }
        
        // Click handler - use actual page number
        pairThumbnail.addEventListener('click', () => {
            currentPageNumber = actualPageNum;
            loadSpread(currentPageNumber);
        });
        
        pagesList.appendChild(pairThumbnail);
    }
    
    console.log(`Rendered covers + ${Math.ceil(contentPages / 2)} content page pairs in sidebar`);
}

// Load spread (two pages side by side)
async function loadSpread(startPageNumber) {
    const leftPage = pages.find(p => p.page_number === startPageNumber);
    const totalPages = book?.page_count || Math.max(pages.length, 25);
    
    // If viewing Front Cover (page 1), pair it with Back Cover (last page)
    // Otherwise, pair with next page
    let rightPage;
    if (startPageNumber === 1) {
        rightPage = pages.find(p => p.page_number === totalPages);
    } else {
        rightPage = pages.find(p => p.page_number === startPageNumber + 1);
    }
    
    if (!leftPage) {
        await createPage(startPageNumber);
        const response = await booksAPI.getOne(bookId);
        pages = response.book.pages || [];
        loadSpread(startPageNumber);
        return;
    }
    
    currentLayout = leftPage.layout_type;
    renderSpread(leftPage, rightPage);
    updateLayoutButtons();
    updateBackgroundColorPicker();
    
    const pageRange = rightPage ? `Page ${startPageNumber}-${rightPage.page_number}` : `Page ${startPageNumber}`;
    
    // Update page display
    if (window.setCurrentPageDisplay) {
        window.setCurrentPageDisplay(pageRange);
    }
}

// Update background color picker with current page's background
function updateBackgroundColorPicker() {
    const pageToEdit = selectedPageNumber || currentPageNumber;
    const page = pages.find(p => p.page_number === pageToEdit);
    
    if (page) {
        const content = typeof page.content === 'string' 
            ? JSON.parse(page.content) 
            : page.content || {};
        
        const backgroundColor = content.backgroundColor || '#ffffff';
        const colorInput = document.getElementById('pageBackgroundColor');
        const colorTextInput = document.getElementById('pageBackgroundColorText');
        
        if (colorInput) {
            colorInput.value = backgroundColor;
        }
        if (colorTextInput) {
            colorTextInput.value = backgroundColor;
        }
    }
}

// Render two-page spread
function renderSpread(leftPage, rightPage) {
    // Clean up all manipulation listeners before re-rendering
    if (typeof manipulationState !== 'undefined' && manipulationState.handlers) {
        manipulationState.handlers.forEach((handlers) => {
            Object.values(handlers).forEach(handlerGroup => {
                handlerGroup.forEach(({ event, handler, target }) => {
                    target.removeEventListener(event, handler);
                });
            });
        });
        manipulationState.handlers.clear();
    }
    manipulationState.isDragging = false;
    manipulationState.isResizing = false;
    manipulationState.activeElement = null;
    
    const canvas = document.getElementById('spreadCanvas');
    if (!canvas) {
        console.error('Spread canvas not found');
        return;
    }
    
    // Force flex layout
    canvas.style.display = 'flex';
    canvas.style.flexDirection = 'row';
    canvas.style.flexWrap = 'nowrap';
    canvas.style.gap = '0';
    canvas.style.alignItems = 'stretch';
    canvas.style.justifyContent = 'center';
    
    // On mobile, ensure proper centering
    if (window.innerWidth <= 768) {
        canvas.style.margin = '0';
        canvas.style.width = 'auto';
        canvas.style.minWidth = 'fit-content';
    }
    
    canvas.innerHTML = '';
    
    // Calculate zoom to fit spread in viewport
    const canvasArea = document.querySelector('.editor-canvas-area');
    
    // Set default selected page if not set or if it's not in current spread
    if (!selectedPageNumber || (selectedPageNumber !== leftPage.page_number && selectedPageNumber !== (rightPage?.page_number))) {
        selectedPageNumber = leftPage.page_number;
    }
    
    // Calculate and apply zoom after a brief delay to ensure DOM is ready
    // Only scale on desktop, not mobile
    setTimeout(() => {
        if (canvasArea && canvas && window.innerWidth > 768) {
            const areaWidth = canvasArea.clientWidth - 40; // Account for padding
            const areaHeight = canvasArea.clientHeight - 40;
            
            // Each page is 400px wide, so spread is ~800px + padding
            const spreadWidth = 800 + 40; // 2 pages @ 400px + padding
            const spreadHeight = 533 + 40; // 400px * 4/3 aspect ratio + padding
            
            // Calculate scale to fit
            const scaleX = areaWidth / spreadWidth;
            const scaleY = areaHeight / spreadHeight;
            const scale = Math.min(scaleX, scaleY, 1); // Don't scale up, only down
            
            canvas.style.transform = `scale(${scale})`;
            canvas.style.transformOrigin = 'center center';
        } else if (canvas && window.innerWidth <= 768) {
            // On mobile, calculate scale to fit both pages fully (zoom out)
            setTimeout(() => {
                const canvasArea = document.querySelector('.editor-canvas-area');
                if (canvasArea && canvas) {
                    // Wait for layout to settle, then measure
                    requestAnimationFrame(() => {
                        requestAnimationFrame(() => {
                            const containerWidth = canvasArea.clientWidth;
                            const containerHeight = canvasArea.clientHeight;
                            const contentWidth = canvas.offsetWidth || canvas.scrollWidth;
                            const contentHeight = canvas.offsetHeight || canvas.scrollHeight;
                            
                            // Calculate scale to fit both width and height - always scale down if needed
                            const scaleX = (containerWidth * 0.95) / contentWidth; // 95% of container to leave some margin
                            const scaleY = (containerHeight * 0.95) / contentHeight;
                            const scale = Math.min(scaleX, scaleY); // Allow scaling down below 1
                            
                            // Always apply scaling to ensure both pages fit
                            canvas.style.transform = `scale(${scale})`;
                            canvas.style.transformOrigin = 'center center';
                            canvas.style.margin = '0 auto';
                            
                            // Recalculate after scaling
                            setTimeout(() => {
                                const scaledWidth = contentWidth * scale;
                                const scaledHeight = contentHeight * scale;
                                
                                if (scaledWidth <= containerWidth) {
                                    const padding = (containerWidth - scaledWidth) / 2;
                                    canvasArea.style.paddingLeft = `${padding}px`;
                                    canvasArea.style.paddingRight = `${padding}px`;
                                    canvasArea.scrollLeft = 0;
                                } else {
                                    canvasArea.style.paddingLeft = '0';
                                    canvasArea.style.paddingRight = '0';
                                    const scrollPosition = (scaledWidth - containerWidth) / 2;
                                    canvasArea.scrollLeft = scrollPosition;
                                }
                            }, 100);
                        });
                    });
                }
            }, 600);
        }
    }, 100);
    
    // Left page
    const leftPageDiv = createPageElement(leftPage, 'left');
    leftPageDiv.style.display = 'block';
    leftPageDiv.style.float = 'none';
    leftPageDiv.style.width = '400px';
    leftPageDiv.style.minWidth = '400px';
    leftPageDiv.style.maxWidth = '400px';
    leftPageDiv.style.flexShrink = '0';
    
    // Add click handler to select this page
    leftPageDiv.addEventListener('click', (e) => {
        // Select page unless clicking on interactive elements (buttons, editable images, text elements)
        const isInteractive = e.target.closest('.editable-image, .text-element, .image-control-btn, .text-control-btn, .remove-text, .remove-image, button');
        if (!isInteractive) {
            selectedPageNumber = leftPage.page_number;
            updatePageSelection();
            updateLayoutButtons();
        }
    });
    
    // Mark as selected
    if (selectedPageNumber === leftPage.page_number) {
        leftPageDiv.classList.add('page-selected');
    }
    
    canvas.appendChild(leftPageDiv);
    
    // Right page (or empty)
    if (rightPage) {
        const rightPageDiv = createPageElement(rightPage, 'right');
        rightPageDiv.style.display = 'block';
        rightPageDiv.style.float = 'none';
        rightPageDiv.style.width = '400px';
        rightPageDiv.style.minWidth = '400px';
        rightPageDiv.style.maxWidth = '400px';
        rightPageDiv.style.flexShrink = '0';
        
        // Add click handler to select this page
        rightPageDiv.addEventListener('click', (e) => {
            // Select page unless clicking on interactive elements (buttons, editable images, text elements)
            const isInteractive = e.target.closest('.editable-image, .text-element, .image-control-btn, .text-control-btn, .remove-text, .remove-image, button');
            if (!isInteractive) {
                selectedPageNumber = rightPage.page_number;
                updatePageSelection();
                updateLayoutButtons();
            }
        });
        
        // Mark as selected
        if (selectedPageNumber === rightPage.page_number) {
            rightPageDiv.classList.add('page-selected');
        }
        
        canvas.appendChild(rightPageDiv);
    } else {
        const emptyPage = document.createElement('div');
        emptyPage.className = 'spread-page';
        emptyPage.style.background = '#fafafa';
        emptyPage.style.border = '1px solid #e5e7eb';
        emptyPage.style.borderLeft = '2px solid #d1d5db';
        emptyPage.style.display = 'block';
        emptyPage.style.float = 'none';
        emptyPage.style.width = '400px';
        emptyPage.style.minWidth = '400px';
        emptyPage.style.maxWidth = '400px';
        emptyPage.style.flexShrink = '0';
        
        // Add page number to empty page
        const pageNumberDisplay = document.createElement('div');
        pageNumberDisplay.className = 'page-number-display';
        // Display content pages as 1-25 (page 2 in DB = page 1 display, etc.)
        const totalPages = book?.page_count || Math.max(pages.length, 25);
        if (leftPage.page_number === 1) {
            pageNumberDisplay.textContent = 'Front Cover';
        } else if (leftPage.page_number === totalPages) {
            pageNumberDisplay.textContent = 'Back Cover';
        } else {
            const displayPageNum = leftPage.page_number - 1;
            pageNumberDisplay.textContent = `Page ${displayPageNum}`;
        }
        pageNumberDisplay.style.left = '10px';
        emptyPage.appendChild(pageNumberDisplay);
        
        canvas.appendChild(emptyPage);
    }
    
    // Update active spread indicator in sidebar
    updateActiveSpreadIndicator(leftPage.page_number, rightPage ? rightPage.page_number : null);
    
    // Update active page indicators
    renderPagesList();
    updatePageSelection();
    
    // Recalculate zoom on window resize
    window.addEventListener('resize', () => {
        const canvas = document.getElementById('spreadCanvas');
        const canvasArea = document.querySelector('.editor-canvas-area');
        if (canvas && canvasArea) {
            const areaWidth = canvasArea.clientWidth - 40;
            const areaHeight = canvasArea.clientHeight - 40;
            const spreadWidth = 800 + 40;
            const spreadHeight = 533 + 40;
            const scaleX = areaWidth / spreadWidth;
            const scaleY = areaHeight / spreadHeight;
            const scale = Math.min(scaleX, scaleY, 1);
            canvas.style.transform = `scale(${scale})`;
        }
    }, { once: false });
}

// Update page selection visual
function updatePageSelection() {
    document.querySelectorAll('.spread-page').forEach(pageEl => {
        pageEl.classList.remove('page-selected');
        const pageNum = parseInt(pageEl.dataset.pageNumber);
        if (pageNum === selectedPageNumber) {
            pageEl.classList.add('page-selected');
        }
    });
}

// Update active spread indicator - now handled by renderPagesList
function updateActiveSpreadIndicator(leftPageNum, rightPageNum) {
    // Just re-render the pages list to update active state
    renderPagesList();
}

// Create editable image element
function createEditableImage(image, pageNumber, imageIndex) {
    // Validate image data
    if (!image || (!image.url && !image.cloudinary_url)) {
        console.error('Invalid image data:', image);
        return null;
    }
    
    const container = document.createElement('div');
    container.className = 'editable-image';
    container.dataset.pageNumber = pageNumber;
    container.dataset.imageIndex = imageIndex;
    container.style.position = 'absolute';
    container.style.left = (image.x || 50) + 'px';
    container.style.top = (image.y || 50) + 'px';
    container.style.width = (image.width || 200) + 'px';
    container.style.height = (image.height || 200) + 'px';
    container.style.cursor = 'move';
    container.style.zIndex = '10';
    container.style.userSelect = 'none';
    
    const img = document.createElement('img');
    const imageUrl = image.url || image.cloudinary_url;
    img.src = imageUrl;
    img.style.width = '100%';
    img.style.height = '100%';
    img.style.objectFit = 'cover';
    img.style.display = 'block';
    img.style.pointerEvents = 'none'; // Prevent image from interfering with drag
    
    // Handle image loading errors
    img.onerror = () => {
        console.error('Failed to load image:', imageUrl);
        img.style.background = '#f0f0f0';
        img.style.display = 'flex';
        img.style.alignItems = 'center';
        img.style.justifyContent = 'center';
        img.innerHTML = '<span style="color: #999; font-size: 12px;">Image failed to load</span>';
    };
    
    if (image.rotation) {
        img.style.transform = `rotate(${image.rotation}deg)`;
    }
    
    // Resize handle
    const resizeHandle = document.createElement('div');
    resizeHandle.className = 'resize-handle';
    resizeHandle.style.cssText = 'position: absolute; bottom: 0; right: 0; width: 20px; height: 20px; background: rgba(102, 126, 234, 0.8); cursor: nwse-resize; border-radius: 50% 0 0 0; display: none; z-index: 100;';
    // Use resize icon (diagonal arrows) instead of X
    resizeHandle.innerHTML = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="position: absolute; bottom: 2px; right: 2px;">
        <polyline points="21 17 21 21 17 21"></polyline>
        <line x1="10" y1="10" x2="21" y2="21"></line>
        <line x1="3" y1="3" x2="14" y2="14"></line>
        <polyline points="3 7 3 3 7 3"></polyline>
    </svg>`;
    
    // Show controls on hover/touch (only resize handle now)
    const showControls = () => {
        resizeHandle.style.display = 'block';
    };
    const hideControls = () => {
        resizeHandle.style.display = 'none';
    };
    
    container.addEventListener('mouseenter', showControls);
    container.addEventListener('mouseleave', hideControls);
    container.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
            showControls();
            setTimeout(hideControls, 3000); // Auto-hide after 3 seconds on touch
        }
    });
    
    // Make draggable and resizable
    makeImageDraggable(container, pageNumber, imageIndex);
    makeResizable(container, pageNumber, imageIndex);
    
    container.appendChild(img);
    container.appendChild(resizeHandle);
    
    return container;
}

// Create page element
function createPageElement(page, side) {
    const pageDiv = document.createElement('div');
    pageDiv.className = 'spread-page';
    pageDiv.dataset.pageNumber = page.page_number;
    pageDiv.dataset.side = side;
    
    // Get total pages - ensure we use the book's page_count, not pages.length
    // pages.length might be less than totalPages if pages haven't been created yet
    const totalPages = book?.page_count || 27; // Default to 27 (1 front + 25 content + 1 back)
    
    // Add cover class for styling - only page 1 and the actual last page
    if (page.page_number === 1) {
        pageDiv.classList.add('book-cover', 'front-cover');
    } else if (page.page_number === totalPages) {
        pageDiv.classList.add('book-cover', 'back-cover');
    }
    
    // Add page number display
    const pageNumberDisplay = document.createElement('div');
    pageNumberDisplay.className = 'page-number-display';
    if (page.page_number === 1) {
        pageNumberDisplay.textContent = 'Front Cover';
    } else if (page.page_number === totalPages) {
        pageNumberDisplay.textContent = 'Back Cover';
    } else {
        // Display content pages as 1-25 (page 2 in DB = page 1 display, etc.)
        const displayPageNum = page.page_number - 1;
        pageNumberDisplay.textContent = `Page ${displayPageNum}`;
    }
    pageDiv.appendChild(pageNumberDisplay);
    
    const content = typeof page.content === 'string' 
        ? JSON.parse(page.content) 
        : page.content;
    
    // Apply background color if set (but preserve cover styling)
    if (content.backgroundColor && !pageDiv.classList.contains('book-cover')) {
        pageDiv.style.background = content.backgroundColor;
    } else if (content.backgroundColor && pageDiv.classList.contains('book-cover')) {
        // For covers, apply as a background layer, not override
        pageDiv.style.setProperty('background', 
            `linear-gradient(135deg, ${content.backgroundColor}dd 0%, ${content.backgroundColor}ee 100%), ` +
            `repeating-linear-gradient(45deg, transparent, transparent 2px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.03) 4px)`,
            'important');
    }
    
    const pageContent = document.createElement('div');
    pageContent.className = `page-content layout-${page.layout_type}`;
    
    // Handle full spread layout
    if (page.layout_type === 'fullspread') {
        if (content.images && content.images.length > 0 && content.images[0]) {
            // Full spread image should cover both pages
            // Only render on left page, image will span both
            if (side === 'left') {
                // Make pageContent position relative to contain absolute positioned full spread
                pageContent.style.position = 'relative';
                pageContent.style.overflow = 'visible';
                
                const fullSpreadContainer = document.createElement('div');
                fullSpreadContainer.className = 'fullspread-container';
                fullSpreadContainer.style.position = 'absolute';
                fullSpreadContainer.style.left = '0';
                fullSpreadContainer.style.top = '0';
                fullSpreadContainer.style.width = '200%'; // Span both pages (left + right)
                fullSpreadContainer.style.height = '100%';
                fullSpreadContainer.style.zIndex = '1';
                fullSpreadContainer.style.overflow = 'hidden';
                
                const fullSpreadImg = document.createElement('img');
                fullSpreadImg.src = content.images[0].url || content.images[0].cloudinary_url;
                fullSpreadImg.style.width = '100%';
                fullSpreadImg.style.height = '100%';
                fullSpreadImg.style.objectFit = 'cover';
                fullSpreadImg.style.display = 'block';
                
                fullSpreadContainer.appendChild(fullSpreadImg);
                pageContent.appendChild(fullSpreadContainer);
            }
            // Right page: render empty but let left page image cover it
            // We still create the page structure but don't add content
        } else {
            const placeholder = document.createElement('div');
            placeholder.className = 'page-placeholder';
            placeholder.innerHTML = `
                <div class="placeholder-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="1.5">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                        <circle cx="8.5" cy="8.5" r="1.5"></circle>
                        <polyline points="21 15 16 10 5 21"></polyline>
                    </svg>
                </div>
                <div class="placeholder-text">Tap or drag image here</div>
            `;
            placeholder.addEventListener('click', (e) => {
                e.stopPropagation();
                if (selectedImage) {
                    addFullSpreadImage(page.page_number);
                } else {
                    alert('Please select an image from the Images panel first');
                }
            }, true);
            
            // Add drop zone for full spread
            placeholder.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.stopPropagation();
                e.dataTransfer.dropEffect = 'copy';
                placeholder.style.background = '#f0f4ff';
            }, true);
            
            placeholder.addEventListener('dragleave', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (!placeholder.contains(e.relatedTarget)) {
                    placeholder.style.background = 'transparent';
                }
            }, true);
            
            placeholder.addEventListener('drop', (e) => {
                e.preventDefault();
                e.stopPropagation();
                placeholder.style.background = 'transparent';
                
                try {
                    // Try multiple data formats
                    let imageDataStr = e.dataTransfer.getData('text/plain') || 
                                     e.dataTransfer.getData('application/json') ||
                                     e.dataTransfer.getData('text');
                    
                    if (!imageDataStr) {
                        console.error('No data in dataTransfer');
                        alert('Failed to get image data. Please try selecting the image first, then drag again.');
                        return;
                    }
                    
                    const imageData = JSON.parse(imageDataStr);
                    console.log('Dropped image for full spread:', imageData);
                    
                    // Validate image data
                    if (!imageData || (!imageData.url && !imageData.cloudinary_url)) {
                        console.error('Invalid image data:', imageData);
                        alert('Invalid image data. Please try selecting the image first.');
                        return;
                    }
                    
                    selectedImage = imageData;
                    if (window.setSelectedImage) {
                        window.setSelectedImage(imageData);
                    }
                    addFullSpreadImage(page.page_number);
                } catch (error) {
                    console.error('Error parsing dropped image data:', error);
                    console.error('Error details:', error.message, error.stack);
                    alert('Failed to add image: ' + error.message + '. Please try selecting the image first, then drag again.');
                }
            }, true);
            
            pageContent.appendChild(placeholder);
        }
    } else {
        // Regular layouts
        const layoutConfig = {
            'single': 1,
            'double': 2,
            'triple': 3,
            'quad': 4
        };
        
        const slotCount = layoutConfig[page.layout_type] || 1;
        const hasContent = content.images && content.images.some(img => img && img.url);
        
        if (!hasContent && slotCount === 1) {
            // Show placeholder for empty single layout
            const placeholder = document.createElement('div');
            placeholder.className = 'page-placeholder';
            placeholder.innerHTML = `
                <div class="placeholder-icon">
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="1.5">
                        <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                        <circle cx="8.5" cy="8.5" r="1.5"></circle>
                        <polyline points="21 15 16 10 5 21"></polyline>
                    </svg>
                </div>
                <div class="placeholder-text">Tap or drag image here</div>
            `;
            placeholder.addEventListener('click', (e) => {
                e.stopPropagation();
                if (selectedImage) {
                    addImageToSlot(page.page_number, 0);
                } else {
                    alert('Please select an image from the Images panel first');
                }
            }, true);
            
            // Add drop zone for drag-and-drop
            placeholder.addEventListener('dragover', (e) => {
                e.preventDefault();
                e.stopPropagation();
                e.dataTransfer.dropEffect = 'copy';
                placeholder.style.background = '#f0f4ff';
            }, true);
            
            placeholder.addEventListener('dragleave', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (!placeholder.contains(e.relatedTarget)) {
                    placeholder.style.background = 'transparent';
                }
            }, true);
            
            placeholder.addEventListener('drop', (e) => {
                e.preventDefault();
                e.stopPropagation();
                placeholder.style.background = 'transparent';
                
                try {
                    // Try multiple data formats
                    let imageDataStr = e.dataTransfer.getData('text/plain') || 
                                     e.dataTransfer.getData('application/json') ||
                                     e.dataTransfer.getData('text');
                    
                    if (!imageDataStr) {
                        console.error('No data in dataTransfer');
                        alert('Failed to get image data. Please try selecting the image first, then drag again.');
                        return;
                    }
                    
                    const imageData = JSON.parse(imageDataStr);
                    console.log('Dropped image:', imageData);
                    
                    // Validate image data
                    if (!imageData || (!imageData.url && !imageData.cloudinary_url)) {
                        console.error('Invalid image data:', imageData);
                        alert('Invalid image data. Please try selecting the image first.');
                        return;
                    }
                    
                    selectedImage = imageData;
                    if (window.setSelectedImage) {
                        window.setSelectedImage(imageData);
                    }
                    addImageToSlot(page.page_number, 0);
                } catch (error) {
                    console.error('Error parsing dropped image data:', error);
                    console.error('Error details:', error.message, error.stack);
                    alert('Failed to add image: ' + error.message + '. Please try selecting the image first, then drag again.');
                }
            }, true);
            
            pageContent.appendChild(placeholder);
        } else {
            for (let i = 0; i < slotCount; i++) {
                const slot = document.createElement('div');
                slot.className = 'image-slot';
                slot.dataset.slotIndex = i;
                slot.dataset.pageNumber = page.page_number;
                
                const image = content.images && content.images[i];
                
                // Always ensure slot is visible and has minimum height
                slot.style.minHeight = '100px';
                slot.style.position = 'relative';
                slot.style.overflow = 'hidden';
                
                if (image && (image.url || image.cloudinary_url)) {
                    // Image fills the entire slot
                    const img = document.createElement('img');
                    img.src = image.url || image.cloudinary_url;
                    img.style.width = '100%';
                    img.style.height = '100%';
                    img.style.objectFit = 'cover';
                    img.style.display = 'block';
                    img.style.pointerEvents = 'none';
                    
                    // Handle image loading errors
                    img.onerror = () => {
                        console.error('Failed to load image:', img.src);
                        img.style.background = '#f0f0f0';
                        img.style.display = 'flex';
                        img.style.alignItems = 'center';
                        img.style.justifyContent = 'center';
                        img.outerHTML = '<div style="width: 100%; height: 100%; background: #f0f0f0; display: flex; align-items: center; justify-content: center; color: #999; font-size: 12px;">Image failed to load</div>';
                    };
                    
                    // Apply rotation if present
                    if (image.rotation) {
                        img.style.transform = `rotate(${image.rotation}deg)`;
                    }
                    
                    slot.appendChild(img);
                    
                    // Only make slot absolutely positioned if user has explicitly moved it
                    // Check if x/y are set and different from default (meaning user moved it)
                    const hasCustomPosition = image.x !== undefined && image.y !== undefined && 
                                            (image.x !== 0 || image.y !== 0);
                    const hasCustomSize = image.width !== undefined && image.height !== undefined;
                    
                    if (hasCustomPosition) {
                        // User has moved this slot - make it absolutely positioned
                        slot.style.position = 'absolute';
                        slot.style.left = image.x + 'px';
                        slot.style.top = image.y + 'px';
                        if (hasCustomSize) {
                            slot.style.width = image.width + 'px';
                            slot.style.height = image.height + 'px';
                        }
                        slot.style.zIndex = '10';
                    } else {
                        // Keep slot in normal flow - stay in layout grid position
                        slot.style.position = 'relative';
                        // If custom size is set, apply it but keep in flow
                        if (hasCustomSize) {
                            slot.style.width = image.width + 'px';
                            slot.style.height = image.height + 'px';
                        }
                    }
                    
                    // Make slot manipulable
                    slot.classList.add('slot-with-image');
                    slot.style.cursor = 'move';
                    slot.style.border = '2px solid #667eea';
                    slot.style.background = 'transparent';
                    slot.style.padding = '0';
                    
                    // Add resize handle to slot
                    const resizeHandle = document.createElement('div');
                    resizeHandle.className = 'slot-resize-handle';
                    // Make larger on mobile for better touch targets (44x44px minimum for touch)
                    const isMobileDevice = window.innerWidth <= 768;
                    const handleSize = isMobileDevice ? '44px' : '20px';
                    const iconSize = isMobileDevice ? '20px' : '12px';
                    resizeHandle.style.cssText = `position: absolute; bottom: 0; right: 0; width: ${handleSize}; height: ${handleSize}; background: rgba(102, 126, 234, 0.9); cursor: nwse-resize; border-radius: 50% 0 0 0; z-index: 1000; display: none; touch-action: none; -webkit-touch-callout: none; user-select: none;`;
                    // Use resize icon (diagonal arrows) instead of X
                    resizeHandle.innerHTML = `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="position: absolute; bottom: ${isMobileDevice ? '8px' : '2px'}; right: ${isMobileDevice ? '8px' : '2px'};">
                        <polyline points="21 17 21 21 17 21"></polyline>
                        <line x1="10" y1="10" x2="21" y2="21"></line>
                        <line x1="3" y1="3" x2="14" y2="14"></line>
                        <polyline points="3 7 3 3 7 3"></polyline>
                    </svg>`;
                    slot.appendChild(resizeHandle);
                    
                    // Show controls on hover (desktop) or tap (mobile) - only resize handle
                    if (isMobileDevice) {
                        // On mobile, show controls on tap
                        let tapTimeout = null;
                        slot.addEventListener('touchstart', (e) => {
                            // Don't show if touching resize handle
                            if (e.target.closest('.slot-resize-handle')) {
                                return;
                            }
                            if (tapTimeout) clearTimeout(tapTimeout);
                            tapTimeout = setTimeout(() => {
                                resizeHandle.style.display = 'block';
                                // Hide after 3 seconds
                                setTimeout(() => {
                                    resizeHandle.style.display = 'none';
                                }, 3000);
                            }, 100);
                        });
                        // Also show on click for mobile
                        slot.addEventListener('click', (e) => {
                            if (e.target.closest('.slot-resize-handle')) {
                                return;
                            }
                            resizeHandle.style.display = 'block';
                            setTimeout(() => {
                                resizeHandle.style.display = 'none';
                            }, 3000);
                        });
                    } else {
                        // Desktop: show on hover
                        slot.addEventListener('mouseenter', () => {
                            resizeHandle.style.display = 'block';
                        });
                        slot.addEventListener('mouseleave', () => {
                            resizeHandle.style.display = 'none';
                        });
                    }
                    
                    // Make slot draggable and resizable
                    makeSlotDraggable(slot, page.page_number, i);
                    makeSlotResizable(slot, page.page_number, i);
                } else {
                    // Empty slot - show placeholder
                    slot.innerHTML = `
                        <div class="placeholder-icon" style="margin-bottom: 8px;">
                            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" stroke-width="1.5">
                                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                                <circle cx="8.5" cy="8.5" r="1.5"></circle>
                                <polyline points="21 15 16 10 5 21"></polyline>
                            </svg>
                        </div>
                        <div class="placeholder-text">Tap or drag image here</div>
                    `;
                }
                
                // Add event listeners to ALL slots (both empty and with images)
                // This allows replacing images and adding to empty slots
                
                // Click handler - only works if clicking on the slot itself, not controls
                // Use a flag to prevent click after drag
                let clickTimeout = null;
                slot.addEventListener('mousedown', (e) => {
                    // Don't trigger if clicking on controls
                    if (e.target.closest('.slot-resize-handle')) {
                        return;
                    }
                    
                    // Set a flag to allow click after mouseup if no drag occurred
                    clickTimeout = setTimeout(() => {
                        clickTimeout = null;
                    }, 300);
                });
                
                slot.addEventListener('click', (e) => {
                    // Don't trigger if clicking on controls
                    if (e.target.closest('.slot-resize-handle')) {
                        return;
                    }
                    
                    // If we just dragged, don't process click
                    if (!clickTimeout) {
                        return;
                    }
                    clearTimeout(clickTimeout);
                    clickTimeout = null;
                    
                    e.stopPropagation();
                    
                    // If slot has an image, select it for manipulation
                    if (image && (image.url || image.cloudinary_url)) {
                        const imageToSelect = {
                            id: image.cloudinary_id || image.id,
                            url: image.url || image.cloudinary_url,
                            cloudinary_url: image.cloudinary_url || image.url,
                            cloudinary_id: image.cloudinary_id || image.id
                        };
                        selectedImage = imageToSelect;
                        window.setSelectedImage(imageToSelect);
                        
                        // Highlight the image in the images panel
                        document.querySelectorAll('.my-image-item').forEach(item => {
                            item.classList.remove('selected');
                            if (item.dataset.imageId === String(imageToSelect.id) || 
                                item.dataset.imageUrl === imageToSelect.url) {
                                item.classList.add('selected');
                            }
                        });
                        
                        console.log('Selected existing image from slot:', imageToSelect);
                        return;
                    }
                    
                    // If no image in slot, add selected image
                    if (selectedImage) {
                        addImageToSlot(page.page_number, i);
                    } else {
                        alert('Please select an image from the Images panel first');
                    }
                }, true);
                
                // Add drop zone for drag-and-drop
                slot.addEventListener('dragover', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    e.dataTransfer.dropEffect = 'copy';
                    slot.style.background = '#f0f4ff';
                    slot.style.borderColor = '#667eea';
                }, true);
                
                slot.addEventListener('dragleave', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    // Only reset if we're actually leaving the slot
                    if (!slot.contains(e.relatedTarget)) {
                        if (image && (image.url || image.cloudinary_url)) {
                            slot.style.background = 'transparent';
                            slot.style.borderColor = '#cbd5e1';
                        } else {
                            slot.style.background = '#f9fafb';
                            slot.style.borderColor = '#d1d5db';
                        }
                    }
                }, true);
                
                slot.addEventListener('drop', (e) => {
                    e.preventDefault();
                    e.stopPropagation();
                    
                    // Reset slot styling
                    if (image && (image.url || image.cloudinary_url)) {
                        slot.style.background = 'transparent';
                        slot.style.borderColor = '#cbd5e1';
                    } else {
                        slot.style.background = '#f9fafb';
                        slot.style.borderColor = '#d1d5db';
                    }
                    
                    try {
                        // Try multiple data formats
                        let imageDataStr = e.dataTransfer.getData('text/plain') || 
                                         e.dataTransfer.getData('application/json') ||
                                         e.dataTransfer.getData('text');
                        
                        if (!imageDataStr) {
                            console.error('No data in dataTransfer');
                            alert('Failed to get image data. Please try selecting the image first, then drag again.');
                            return;
                        }
                        
                        const imageData = JSON.parse(imageDataStr);
                        console.log('Dropped image:', imageData);
                        
                        // Validate image data
                        if (!imageData || (!imageData.url && !imageData.cloudinary_url)) {
                            console.error('Invalid image data:', imageData);
                            alert('Invalid image data. Please try selecting the image first.');
                            return;
                        }
                        
                        // Set as selected image and add to slot
                        selectedImage = imageData;
                        if (window.setSelectedImage) {
                            window.setSelectedImage(imageData);
                        }
                        addImageToSlot(page.page_number, i);
                    } catch (error) {
                        console.error('Error parsing dropped image data:', error);
                        console.error('Error details:', error.message, error.stack);
                        alert('Failed to add image: ' + error.message + '. Please try selecting the image first, then drag again.');
                    }
                }, true);
                
                pageContent.appendChild(slot);
            }
        }
    }
    
    // Add text elements
    if (content.texts) {
        content.texts.forEach((textItem, index) => {
            addTextElement(textItem, index, pageDiv, page.page_number);
        });
    }
    
    pageDiv.appendChild(pageContent);
    return pageDiv;
}

// Add image to slot
function addImageToSlot(pageNumber, slotIndex) {
    console.log('addImageToSlot called for page', pageNumber, 'slot', slotIndex);
    console.log('selectedImage:', selectedImage);
    if (!selectedImage) {
        alert('Please select an image from "My Images" first');
        return;
    }
    
    const page = pages.find(p => p.page_number === pageNumber);
    if (!page) {
        console.error('Page not found:', pageNumber);
        return;
    }
    
    const content = typeof page.content === 'string' 
        ? JSON.parse(page.content) 
        : page.content || {};
    
    if (!content.images) {
        content.images = [];
    }
    
    // Ensure images array is large enough
    while (content.images.length <= slotIndex) {
        content.images.push(null);
    }
    
    // Get image URL - prioritize cloudinary_url
    const imageUrl = selectedImage.cloudinary_url || selectedImage.url;
    const imageId = selectedImage.cloudinary_id || selectedImage.id;
    
    if (!imageUrl) {
        console.error('No image URL found in selectedImage:', selectedImage);
        alert('Image URL is missing. Please try selecting the image again.');
        return;
    }
    
    // Get page element to calculate position
    const pageElement = document.querySelector(`.spread-page[data-page-number="${pageNumber}"]`);
    const pageContent = pageElement?.querySelector('.page-content');
    const slot = pageContent?.querySelector(`.image-slot[data-slot-index="${slotIndex}"]`);
    
    let imageData;
    if (slot) {
        // For new images, don't set x/y - let slot stay in its layout position
        // Only store width/height if slot has been resized
        // x/y will be set when user drags the slot
        imageData = {
            url: imageUrl,
            cloudinary_url: imageUrl,
            cloudinary_id: imageId,
            // Don't set x/y initially - slot stays in layout flow
            // x and y will be set when user moves the slot
            width: slot.offsetWidth, // Store current slot width
            height: slot.offsetHeight, // Store current slot height
            rotation: 0
        };
    } else {
        // Fallback if slot not found
        imageData = {
            url: imageUrl,
            cloudinary_url: imageUrl,
            cloudinary_id: imageId,
            // Don't set x/y - will be set when user moves it
            width: 200,
            height: 200,
            rotation: 0
        };
    }
    
    // Store image data
    content.images[slotIndex] = imageData;
    
    console.log('Adding image to slot:', imageData);
    
    // Update page content
    page.content = content;
    
    // Save page
    savePage(pageNumber);
}

// Add full spread image
function addFullSpreadImage(pageNumber) {
    if (!selectedImage) {
        alert('Please select an image from "My Images" first');
        return;
    }
    
    const page = pages.find(p => p.page_number === pageNumber);
    const content = typeof page.content === 'string' 
        ? JSON.parse(page.content) 
        : page.content;
    
    if (!content.images) {
        content.images = [];
    }
    
    // Use cloudinary_url if available, otherwise url
    const imageUrl = selectedImage.url || selectedImage.cloudinary_url;
    
    content.images[0] = {
        url: imageUrl,
        cloudinary_url: imageUrl, // Store both for compatibility
        cloudinary_id: selectedImage.id || selectedImage.cloudinary_id,
        fullSpread: true
    };
    
    // Also need to set layout to fullspread if not already
    if (page.layout_type !== 'fullspread') {
        page.layout_type = 'fullspread';
        currentLayout = 'fullspread';
        updateLayoutButtons();
    }
    
    savePage(pageNumber);
}

// Remove image from page
function removeImageFromPage(pageNumber, slotIndex) {
    const page = pages.find(p => p.page_number === pageNumber);
    const content = typeof page.content === 'string' 
        ? JSON.parse(page.content) 
        : page.content;
    
    if (content.images) {
        content.images[slotIndex] = null;
        content.images = content.images.filter(img => img !== null);
    }
    
    savePage(pageNumber);
}

// Global variable to track selected text element
let selectedTextElement = null;

// Add text element with drag functionality
function addTextElement(textItem, index, pageDiv, pageNumber) {
    const textEl = document.createElement('div');
    textEl.className = 'text-element';
    textEl.style.position = 'absolute';
    textEl.style.left = (textItem.x || 50) + 'px';
    textEl.style.top = (textItem.y || 50) + 'px';
    textEl.style.color = textItem.color || '#000000';
    textEl.style.fontSize = (textItem.fontSize || 16) + 'px';
    textEl.style.fontFamily = textItem.fontFamily || 'Arial, sans-serif';
    textEl.style.cursor = 'move';
    textEl.style.userSelect = 'none';
    textEl.textContent = textItem.text || '';
    textEl.dataset.textIndex = index;
    textEl.dataset.pageNumber = pageNumber;
    
    // Make text content editable
    textEl.contentEditable = 'true';
    textEl.style.outline = 'none';
    textEl.style.minWidth = '50px';
    textEl.style.minHeight = '20px';
    
    // Handle text content changes
    let textChangeTimeout = null;
    textEl.addEventListener('input', (e) => {
        // Debounce saves
        clearTimeout(textChangeTimeout);
        textChangeTimeout = setTimeout(() => {
            const page = pages.find(p => p.page_number === pageNumber);
            if (page && page.content) {
                const content = typeof page.content === 'string' 
                    ? JSON.parse(page.content) 
                    : page.content;
                
                if (content.texts && content.texts[index]) {
                    content.texts[index].text = textEl.textContent || textEl.innerText;
                    savePage(pageNumber);
                }
            }
        }, 500);
    });
    
    // Prevent drag when editing text
    textEl.addEventListener('focus', () => {
        textEl.style.cursor = 'text';
    });
    textEl.addEventListener('blur', () => {
        textEl.style.cursor = 'move';
    });
    
    // Function to select text element
    const selectTextElement = (e) => {
        // Don't select if clicking/touching on resize handle
        if (e.target.closest('.text-resize-handle')) {
            return;
        }
        // Don't select if element is being edited
        if (document.activeElement === textEl && textEl.contentEditable === 'true') {
            return;
        }
        e.stopPropagation();
        e.preventDefault();
        // Remove selection from all text elements
        document.querySelectorAll('.text-element').forEach(el => {
            el.classList.remove('text-selected');
        });
        // Select this element
        textEl.classList.add('text-selected');
        selectedTextElement = textEl;
        // Update text property inputs to match selected text
        updateTextPropertyInputs(textItem);
        // Update resize handle visibility
        updateResizeHandleVisibility();
    };
    
    // Add click handler for mouse devices
    textEl.addEventListener('click', selectTextElement);
    
    // Add touchstart handler for touch devices - select immediately on tap
    textEl.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1 && !e.target.closest('.text-resize-handle')) {
            // Select immediately on touch (tap)
            selectTextElement(e);
        }
    }, { passive: false });
    
    // Resize handle with resize icon
    const resizeHandle = document.createElement('div');
    resizeHandle.className = 'text-resize-handle';
    const isMobileDevice = window.innerWidth <= 768;
    const handleSize = isMobileDevice ? '44px' : '20px';
    const iconSize = isMobileDevice ? '16px' : '12px';
    resizeHandle.style.cssText = `position: absolute; bottom: ${isMobileDevice ? '-8px' : '-5px'}; right: ${isMobileDevice ? '-8px' : '-5px'}; width: ${handleSize}; height: ${handleSize}; background: rgba(102, 126, 234, 0.9); cursor: nwse-resize; border-radius: 50%; display: none; z-index: 1000; touch-action: none; -webkit-touch-callout: none; user-select: none;`;
    resizeHandle.innerHTML = `<svg width="${iconSize}" height="${iconSize}" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="position: absolute; bottom: ${isMobileDevice ? '8px' : '2px'}; right: ${isMobileDevice ? '8px' : '2px'};">
        <polyline points="21 17 21 21 17 21"></polyline>
        <line x1="10" y1="10" x2="21" y2="21"></line>
        <line x1="3" y1="3" x2="14" y2="14"></line>
        <polyline points="3 7 3 3 7 3"></polyline>
    </svg>`;
    
    // Show controls on hover/touch or when selected
    const showControls = () => {
        resizeHandle.style.display = 'block';
    };
    const hideControls = () => {
        // Only hide if not selected
        if (!textEl.classList.contains('text-selected')) {
            resizeHandle.style.display = 'none';
        }
    };
    
    // Show resize handle when selected
    const updateResizeHandleVisibility = () => {
        if (textEl.classList.contains('text-selected')) {
            resizeHandle.style.display = 'block';
            // On mobile, make it more visible and easier to tap
            if (isMobileDevice) {
                resizeHandle.style.display = 'block';
                resizeHandle.style.opacity = '1';
                resizeHandle.style.background = 'rgba(102, 126, 234, 1)';
            }
        } else {
            resizeHandle.style.display = 'none';
        }
    };
    
    textEl.addEventListener('mouseenter', showControls);
    textEl.addEventListener('mouseleave', hideControls);
    textEl.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1 && !e.target.closest('.text-resize-handle')) {
            showControls();
            setTimeout(() => {
                if (!textEl.classList.contains('text-selected')) {
                    hideControls();
                }
            }, 3000);
        }
    });
    
    // Watch for selection changes
    const observer = new MutationObserver(updateResizeHandleVisibility);
    observer.observe(textEl, { attributes: true, attributeFilter: ['class'] });
    
    // Append resize handle first (before making resizable)
    textEl.appendChild(resizeHandle);
    
    // Make draggable and resizable
    if (typeof makeTextDraggable === 'function') {
        makeTextDraggable(textEl, pageNumber, index);
    }
    if (typeof makeTextResizable === 'function') {
        makeTextResizable(textEl, pageNumber, index);
    }
    
    pageDiv.appendChild(textEl);
}

// Make element draggable
function makeDraggable(element, pageNumber, textIndex) {
    let isDragging = false;
    
    element.addEventListener('mousedown', (e) => {
        if (e.target.classList.contains('remove-text')) return;
        
        isDragging = true;
        element.classList.add('dragging');
        
        const rect = element.getBoundingClientRect();
        const pageRect = element.parentElement.getBoundingClientRect();
        dragOffset.x = e.clientX - rect.left;
        dragOffset.y = e.clientY - rect.top;
        
        const moveHandler = (e) => {
            if (!isDragging) return;
            
            const newX = e.clientX - pageRect.left - dragOffset.x;
            const newY = e.clientY - pageRect.top - dragOffset.y;
            
            element.style.left = Math.max(0, Math.min(newX, element.parentElement.offsetWidth - element.offsetWidth)) + 'px';
            element.style.top = Math.max(0, Math.min(newY, element.parentElement.offsetHeight - element.offsetHeight)) + 'px';
        };
        
        const upHandler = () => {
            isDragging = false;
            element.classList.remove('dragging');
            
            const page = pages.find(p => p.page_number === pageNumber);
            const content = typeof page.content === 'string' 
                ? JSON.parse(page.content) 
                : page.content;
            
            if (content.texts && content.texts[textIndex]) {
                content.texts[textIndex].x = parseInt(element.style.left);
                content.texts[textIndex].y = parseInt(element.style.top);
                savePage(pageNumber);
            }
            
            document.removeEventListener('mousemove', moveHandler);
            document.removeEventListener('mouseup', upHandler);
        };
        
        document.addEventListener('mousemove', moveHandler);
        document.addEventListener('mouseup', upHandler);
    });
}

// Remove text from page
function removeTextFromPage(pageNumber, textIndex) {
    const page = pages.find(p => p.page_number === pageNumber);
    const content = typeof page.content === 'string' 
        ? JSON.parse(page.content) 
        : page.content;
    
    if (content.texts) {
        content.texts.splice(textIndex, 1);
    }
    
    savePage(pageNumber);
}

// Save page
async function savePage(pageNumber) {
    const page = pages.find(p => p.page_number === pageNumber);
    if (!page) {
        console.error('Page not found for saving:', pageNumber);
        return;
    }
    
    const content = typeof page.content === 'string' 
        ? JSON.parse(page.content) 
        : page.content || {};
    
    // Ensure images array exists and is valid
    // Don't filter out nulls - keep array structure to preserve slot positions
    if (content.images) {
        content.images = content.images.map((img, index) => {
            if (!img) return null; // Keep null for empty slots
            // Ensure all required properties exist
            return {
                url: img.url || img.cloudinary_url,
                cloudinary_url: img.cloudinary_url || img.url,
                cloudinary_id: img.cloudinary_id || img.id,
                x: img.x || 0,
                y: img.y || 0,
                width: img.width || 200,
                height: img.height || 200,
                rotation: img.rotation || 0
            };
        });
    }
    
    // Use page's layout_type, fallback to currentLayout
    const layoutToSave = page.layout_type || currentLayout;
    
    try {
        console.log('Saving page', pageNumber, 'with content:', JSON.stringify(content, null, 2));
        await booksAPI.updatePage(bookId, pageNumber, layoutToSave, content);
        
        // Update local page data
        page.content = content;
        
        // Reload the current spread to show updated content
        // Always preserve the current view - don't switch spreads when saving
        setTimeout(() => {
            // Always reload the current spread to maintain page positions
            loadSpread(currentPageNumber);
        }, 100);
    } catch (error) {
        console.error('Failed to save page:', error);
        alert('Failed to save page: ' + (error.message || 'Unknown error'));
    }
}

// Layout selection - handled by setupLayoutHandlers above

// Upload image handler
function setupImageUpload() {
    const imageInput = document.getElementById('imageInput');
    if (!imageInput) {
        console.warn('Image input not found');
        return;
    }
    
    // Remove any existing listeners by cloning
    const newInput = imageInput.cloneNode(true);
    imageInput.parentNode.replaceChild(newInput, imageInput);
    
    newInput.addEventListener('change', async (e) => {
        const files = Array.from(e.target.files);
        if (files.length === 0) return;
        
        console.log(`Uploading ${files.length} image(s)...`);
        
        let successCount = 0;
        for (const file of files) {
            try {
                await uploadImageFile(file);
                successCount++;
            } catch (error) {
                console.error('Upload error:', error);
                // Error already shown in uploadImageFile
            }
        }
        
        if (successCount > 0) {
            console.log(`Successfully uploaded ${successCount} image(s)`);
            // Images are already reloaded by uploadImageFile -> loadMyImages
        }
        
        newInput.value = ''; // Reset input
    });
    
    console.log('Image upload handler set up');
}

// Setup image upload when ready
if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupImageUpload);
    } else {
        setupImageUpload();
    }
}

// Update text property inputs with selected text values
function updateTextPropertyInputs(textItem) {
    const textContentInput = document.getElementById('textContentInput');
    const textColorInput = document.getElementById('textColor');
    const textSizeInput = document.getElementById('textSize');
    const textFontInput = document.getElementById('textFont');
    
    if (textContentInput && textItem && textItem.text !== undefined) {
        textContentInput.value = textItem.text || '';
        textContentInput.disabled = false;
        textContentInput.placeholder = 'Edit text content here';
    } else if (textContentInput) {
        textContentInput.value = '';
        textContentInput.disabled = true;
        textContentInput.placeholder = 'Select a text element to edit, or add a new text block';
    }
    
    if (textColorInput && textItem && textItem.color) {
        textColorInput.value = textItem.color;
    }
    if (textSizeInput && textItem && textItem.fontSize) {
        textSizeInput.value = textItem.fontSize;
    }
    if (textFontInput && textItem && textItem.fontFamily) {
        textFontInput.value = textItem.fontFamily;
    }
}

// Apply text properties to selected text element
function applyTextProperties() {
    if (!selectedTextElement) return;
    
    const pageNumber = parseInt(selectedTextElement.dataset.pageNumber);
    const textIndex = parseInt(selectedTextElement.dataset.textIndex);
    
    const textContent = document.getElementById('textContentInput')?.value || '';
    const textColor = document.getElementById('textColor')?.value || '#000000';
    const fontSize = parseInt(document.getElementById('textSize')?.value) || 16;
    const fontFamily = document.getElementById('textFont')?.value || 'Arial, sans-serif';
    
    // Update visual appearance
    selectedTextElement.textContent = textContent;
    selectedTextElement.style.color = textColor;
    selectedTextElement.style.fontSize = fontSize + 'px';
    selectedTextElement.style.fontFamily = fontFamily;
    
    // Update page data
    const page = pages.find(p => p.page_number === pageNumber);
    if (page && page.content) {
        const content = typeof page.content === 'string' 
            ? JSON.parse(page.content) 
            : page.content;
        
        if (content.texts && content.texts[textIndex]) {
            content.texts[textIndex].text = textContent;
            content.texts[textIndex].color = textColor;
            content.texts[textIndex].fontSize = fontSize;
            content.texts[textIndex].fontFamily = fontFamily;
            savePage(pageNumber);
        }
    }
}

// Add text button - handled by manual-editor-ui.js
function setupTextEditor() {
    // Text editor is handled by manual-editor-ui.js
    // Just need to handle form submission
    const textForm = document.getElementById('textEditorForm');
    if (!textForm) return;
    
    textForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const leftPage = pages.find(p => p.page_number === currentPageNumber);
        if (!leftPage) return;
        
        const content = typeof leftPage.content === 'string' 
            ? JSON.parse(leftPage.content) 
            : leftPage.content;
        
        if (!content.texts) {
            content.texts = [];
        }
        
        content.texts.push({
            text: document.getElementById('textContent').value,
            color: document.getElementById('textColor').value,
            fontSize: parseInt(document.getElementById('textSize').value),
            fontFamily: document.getElementById('textFont').value,
            x: 50,
            y: 50
        });
        
        const textModal = document.getElementById('textEditorModal');
        if (textModal) textModal.style.display = 'none';
        textForm.reset();
        savePage(currentPageNumber);
    });
    
    // Add event listeners to text property inputs to apply changes
    const textContentInput = document.getElementById('textContentInput');
    const textColorInput = document.getElementById('textColor');
    const textSizeInput = document.getElementById('textSize');
    const textFontInput = document.getElementById('textFont');
    
    if (textContentInput) {
        // Debounce text content changes for better performance
        let textContentTimeout = null;
        textContentInput.addEventListener('input', () => {
            clearTimeout(textContentTimeout);
            textContentTimeout = setTimeout(() => {
                applyTextProperties();
            }, 300);
        });
        textContentInput.addEventListener('change', applyTextProperties);
    }
    
    if (textColorInput) {
        textColorInput.addEventListener('change', applyTextProperties);
        textColorInput.addEventListener('input', applyTextProperties);
    }
    if (textSizeInput) {
        textSizeInput.addEventListener('change', applyTextProperties);
        textSizeInput.addEventListener('input', applyTextProperties);
    }
    if (textFontInput) {
        textFontInput.addEventListener('change', applyTextProperties);
    }
}

// Text editor form is handled in setupTextEditor function - no duplicate listener needed

// Navigation buttons - not in current UI design
function setupNavigation() {
    // Navigation handled via page thumbnails in left sidebar
}

// Save functionality (can be triggered from menu or keyboard shortcut)
function setupSaveHandler() {
    document.addEventListener('keydown', async (e) => {
        if (e.ctrlKey && e.key === 's') {
            e.preventDefault();
            try {
                await booksAPI.update(bookId, { status: 'draft' });
                alert('Book saved successfully!');
            } catch (error) {
                alert('Failed to save: ' + error.message);
            }
        }
    });
}

// Generate PDF handler
function setupPdfHandler() {
    if (window.setPdfHandler) {
        window.setPdfHandler(async () => {
            try {
                await pdfAPI.generate(bookId);
                await booksAPI.update(bookId, { status: 'completed' });
            } catch (error) {
                alert('Failed to generate PDF: ' + error.message);
            }
        });
    }
}

// Save all pages to ensure everything is saved
async function saveAllPages() {
    const savePromises = pages.map(page => {
        if (page && page.content) {
            const content = typeof page.content === 'string' 
                ? JSON.parse(page.content) 
                : page.content;
            const layoutType = page.layout_type || currentLayout;
            return booksAPI.updatePage(bookId, page.page_number, layoutType, content);
        }
        return Promise.resolve();
    });
    
    await Promise.all(savePromises);
}

// Setup header button handlers
function setupHeaderHandlers() {
    if (window.setSaveDraftHandler) {
        window.setSaveDraftHandler(async () => {
            try {
                // Save all pages first to ensure everything is saved
                await saveAllPages();
                // Then update book status to draft
                await booksAPI.update(bookId, { status: 'draft' });
                alert('Book saved successfully!');
            } catch (error) {
                console.error('Failed to save draft:', error);
                alert('Failed to save: ' + (error.message || 'Unknown error'));
            }
        });
    }
    
    if (window.setPreviewHandler) {
        window.setPreviewHandler(async () => {
            try {
                // Save all pages before previewing to ensure preview is accurate
                await saveAllPages();
                // Navigate to preview
                window.location.href = `preview.html?bookId=${bookId}`;
            } catch (error) {
                console.error('Failed to save before preview:', error);
                alert('Failed to save pages. Please try again.');
            }
        });
    }
    
    if (window.setExportPdfHandler) {
        window.setExportPdfHandler(async () => {
            try {
                // Save all pages first
                await saveAllPages();
                
                // Show loading state
                const exportBtn = document.getElementById('exportPdfBtn');
                const originalText = exportBtn ? exportBtn.innerHTML : '';
                if (exportBtn) {
                    exportBtn.disabled = true;
                    exportBtn.innerHTML = '<span class="btn-icon">⏳</span><span class="btn-text">Generating PDF...</span>';
                }
                
                // Generate PDF
                await pdfAPI.generate(bookId);
                
                // Update book status to completed
                await booksAPI.update(bookId, { status: 'completed' });
                
                // Reset button
                if (exportBtn) {
                    exportBtn.disabled = false;
                    exportBtn.innerHTML = originalText;
                }
                
                alert('PDF generated and downloaded successfully!');
            } catch (error) {
                console.error('Failed to generate PDF:', error);
                const exportBtn = document.getElementById('exportPdfBtn');
                if (exportBtn) {
                    exportBtn.disabled = false;
                }
                alert('Failed to generate PDF: ' + (error.message || 'Unknown error'));
            }
        });
    }
}

// Change page layout
window.changePageLayout = function(layout) {
    // Use selectedPageNumber if set, otherwise use currentPageNumber (left page)
    const pageToEdit = selectedPageNumber || currentPageNumber;
    console.log('Changing layout to:', layout, 'for page:', pageToEdit);
    
    const page = pages.find(p => p.page_number === pageToEdit);
    if (page) {
        page.layout_type = layout;
        currentLayout = layout; // Update current layout for display
        updateLayoutButtons();
        console.log('Saving page with new layout:', layout);
        savePage(pageToEdit);
    } else {
        console.error('Page not found for page number:', pageToEdit);
    }
};

// Helper function to convert hex to RGB
function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

// Change page background color
window.changePageBackgroundColor = function(color) {
    const pageToEdit = selectedPageNumber || currentPageNumber;
    console.log('Changing background color to:', color, 'for page:', pageToEdit);
    
    const page = pages.find(p => p.page_number === pageToEdit);
    if (page) {
        const content = typeof page.content === 'string' 
            ? JSON.parse(page.content) 
            : page.content || {};
        
        content.backgroundColor = color;
        page.content = JSON.stringify(content);
        
        // Update the page element's background
        const pageElement = document.querySelector(`.spread-page[data-page-number="${pageToEdit}"]`);
        if (pageElement) {
            // For covers, blend with cover styling to preserve texture
            if (pageElement.classList.contains('book-cover')) {
                // Use CSS custom property to allow CSS to handle the blending
                pageElement.style.setProperty('--cover-bg-color', color);
                // Apply as overlay, preserving cover texture
                const rgb = hexToRgb(color);
                if (rgb) {
                    pageElement.style.background = 
                        `linear-gradient(135deg, rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.95) 0%, rgba(${rgb.r}, ${rgb.g}, ${rgb.b}, 0.98) 100%), ` +
                        `repeating-linear-gradient(45deg, transparent, transparent 2px, rgba(255,255,255,0.03) 2px, rgba(255,255,255,0.03) 4px)`;
                } else {
                    pageElement.style.background = color;
                }
            } else {
                // For regular pages, update the background
                pageElement.style.background = color;
            }
        }
        
        console.log('Saving page with new background color:', color);
        savePage(pageToEdit);
    } else {
        console.error('Page not found for page number:', pageToEdit);
    }
};

// Setup layout handlers
function setupLayoutHandlers() {
    // Layout change is now handled by window.changePageLayout
    // This function is kept for compatibility
}

function updateLayoutButtons() {
    // Get the layout of the currently selected page
    const pageToEdit = selectedPageNumber || currentPageNumber;
    const page = pages.find(p => p.page_number === pageToEdit);
    const pageLayout = page ? page.layout_type : currentLayout;
    
    // Update layout cards in right sidebar
    document.querySelectorAll('.layout-card').forEach(card => {
        card.classList.toggle('active', card.dataset.layout === pageLayout);
    });
}

// Setup background color handlers
function setupBackgroundColorHandlers() {
    const colorInput = document.getElementById('pageBackgroundColor');
    const colorTextInput = document.getElementById('pageBackgroundColorText');
    const resetBtn = document.getElementById('resetBackgroundColor');
    
    if (colorInput) {
        colorInput.addEventListener('input', (e) => {
            const color = e.target.value;
            if (colorTextInput) {
                colorTextInput.value = color;
            }
            if (window.changePageBackgroundColor) {
                window.changePageBackgroundColor(color);
            }
        });
    }
    
    if (colorTextInput) {
        colorTextInput.addEventListener('input', (e) => {
            const color = e.target.value;
            // Validate hex color
            if (/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/.test(color)) {
                if (colorInput) {
                    colorInput.value = color;
                }
                if (window.changePageBackgroundColor) {
                    window.changePageBackgroundColor(color);
                }
            }
        });
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            const defaultColor = '#ffffff';
            if (colorInput) {
                colorInput.value = defaultColor;
            }
            if (colorTextInput) {
                colorTextInput.value = defaultColor;
            }
            if (window.changePageBackgroundColor) {
                window.changePageBackgroundColor(defaultColor);
            }
        });
    }
}

// Navigation buttons
function setupNavigation() {
    const prevBtn = document.getElementById('prevPageBtn');
    const nextBtn = document.getElementById('nextPageBtn');
    
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentPageNumber > 1) {
                currentPageNumber = Math.max(1, currentPageNumber - 2);
                loadSpread(currentPageNumber);
                renderPagesList();
            }
        });
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            const totalPages = pages.length;
            if (currentPageNumber < totalPages - 1) {
                currentPageNumber = Math.min(totalPages - 1, currentPageNumber + 2);
                loadSpread(currentPageNumber);
                renderPagesList();
            }
        });
    }
}

// Setup handlers when DOM is ready
if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setupLayoutHandlers();
            setupNavigation();
        });
    } else {
        setupLayoutHandlers();
        setupNavigation();
    }
}

// Initialize
function initializeManualMode() {
    // Get book ID if not already set
    if (!bookId && typeof window !== 'undefined' && typeof URLSearchParams !== 'undefined') {
        const urlParams = new URLSearchParams(window.location.search);
        bookId = urlParams.get('bookId');
    }
    
    if (!bookId) {
        if (typeof window !== 'undefined') {
            window.location.href = 'dashboard.html';
        }
        return;
    }
    
    // Verify myImages container exists
    const myImagesContainer = document.getElementById('myImages');
    if (!myImagesContainer) {
        console.error('myImages container not found in DOM during initialization');
        // Retry after a short delay
        setTimeout(() => {
            const retryContainer = document.getElementById('myImages');
            if (retryContainer) {
                console.log('myImages container found on retry');
            }
        }, 500);
    } else {
        console.log('myImages container found, ready to render images');
    }
    
    setupTextEditor();
    setupHeaderHandlers();
    setupBackgroundColorHandlers();
    loadBook();
    
    // Load images immediately - don't wait for tab click
    console.log('Initializing: Loading images...');
    setTimeout(() => {
        loadMyImages();
    }, 1000); // Small delay to ensure DOM is ready
}

// Start initialization
checkAuth();

