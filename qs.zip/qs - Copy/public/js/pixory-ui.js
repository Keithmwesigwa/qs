// Pixory-style UI interactions

document.addEventListener('DOMContentLoaded', () => {
    // Panel tabs
    const panelTabs = document.querySelectorAll('.panel-tab');
    const panelSections = document.querySelectorAll('.panel-section');
    
    panelTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.dataset.tab;
            
            // Update active tab
            panelTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Update active section
            panelSections.forEach(s => s.classList.remove('active'));
            const targetSection = document.getElementById(targetTab + 'Panel');
            if (targetSection) {
                targetSection.classList.add('active');
            }
        });
    });
    
    // Toolbar buttons
    const toolbarBtns = document.querySelectorAll('.toolbar-btn');
    
    toolbarBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            toolbarBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            const tool = btn.dataset.tool;
            handleToolbarClick(tool);
        });
    });
    
    // Layout thumbnails
    const layoutThumbnails = document.querySelectorAll('.layout-thumbnail');
    
    layoutThumbnails.forEach(thumbnail => {
        thumbnail.addEventListener('click', () => {
            layoutThumbnails.forEach(t => t.classList.remove('active'));
            thumbnail.classList.add('active');
            
            const layout = thumbnail.dataset.layout;
            if (window.currentLayoutHandler) {
                window.currentLayoutHandler(layout);
            }
        });
    });
    
    // Page dropdown
    const pageDropdownBtn = document.getElementById('pageDropdownBtn');
    const pageDropdown = document.getElementById('pageDropdown');
    
    if (pageDropdownBtn && pageDropdown) {
        pageDropdownBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            pageDropdown.style.display = pageDropdown.style.display === 'none' ? 'block' : 'none';
        });
        
        document.addEventListener('click', (e) => {
            if (!pageDropdown.contains(e.target) && !pageDropdownBtn.contains(e.target)) {
                pageDropdown.style.display = 'none';
            }
        });
    }
    
    // Order button
    const orderBtn = document.getElementById('orderBtn');
    if (orderBtn) {
        orderBtn.addEventListener('click', () => {
            // Trigger PDF generation
            if (window.generatePdfHandler) {
                window.generatePdfHandler();
            }
        });
    }
});

function handleToolbarClick(tool) {
    switch(tool) {
        case 'photos':
            // Show photo upload/selection
            document.getElementById('imageInput').click();
            break;
        case 'ideas':
            // Switch to ideas panel
            document.querySelector('.panel-tab[data-tab="ideas"]').click();
            break;
        case 'backgrounds':
            // Show background options (can be implemented later)
            console.log('Backgrounds tool clicked');
            break;
        case 'smart':
            // Show smart suggestions (can be implemented later)
            console.log('Smart tool clicked');
            break;
        case 'templates':
            // Show templates (can be implemented later)
            console.log('Templates tool clicked');
            break;
    }
}

// Export functions for manual-mode.js to use
window.setCurrentPageDisplay = function(text) {
    const display = document.getElementById('currentPageDisplay');
    if (display) {
        display.textContent = text;
    }
};

window.setLayoutHandler = function(handler) {
    window.currentLayoutHandler = handler;
};

window.setPdfHandler = function(handler) {
    window.generatePdfHandler = handler;
};

window.updatePagesList = function(pages, currentPage, onPageClick) {
    const pagesList = document.getElementById('pagesList');
    if (!pagesList) return;
    
    pagesList.innerHTML = '';
    
    pages.forEach(page => {
        const item = document.createElement('div');
        item.className = 'page-item-dropdown';
        if (page.page_number === currentPage) {
            item.classList.add('active');
        }
        item.textContent = `Page ${page.page_number}`;
        item.addEventListener('click', () => {
            onPageClick(page.page_number);
            document.getElementById('pageDropdown').style.display = 'none';
        });
        pagesList.appendChild(item);
    });
};

