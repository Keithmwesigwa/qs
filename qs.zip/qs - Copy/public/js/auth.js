// Wait for DOM to load
if (typeof window !== 'undefined' && typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            initializeAuth();
        });
    } else {
        // DOM is already loaded
        initializeAuth();
    }
}

function initializeAuth() {
    if (typeof window === 'undefined') {
        return;
    }
    
    // Check if we're on login or register page
    const isLoginPage = window.location.pathname.includes('login.html');
    const isRegisterPage = window.location.pathname.includes('register.html');

    // Redirect if already logged in
    if (getToken() && (isLoginPage || isRegisterPage)) {
        window.location.href = 'dashboard.html';
        return;
    }

    // Handle login form
    if (isLoginPage) {
        setupLoginForm();
    }

    // Handle register form
    if (isRegisterPage) {
        setupRegisterForm();
    }
}

function setupLoginForm() {
    const loginForm = document.getElementById('loginForm');
    if (!loginForm) {
        console.error('Login form not found');
        return;
    }

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const errorDiv = document.getElementById('errorMessage');
        const loadingDiv = document.getElementById('loadingIndicator');
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        
        errorDiv.classList.remove('show');
        errorDiv.textContent = '';
        if (loadingDiv) loadingDiv.style.display = 'block';
        submitBtn.disabled = true;

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        console.log('Attempting login for:', email);

        try {
            const response = await authAPI.login(email, password);
            console.log('Login successful:', response);
            setToken(response.token);
            setUser(response.user);
            window.location.href = 'dashboard.html';
        } catch (error) {
            console.error('Login error:', error);
            errorDiv.textContent = error.message || 'Login failed. Please check your credentials.';
            errorDiv.classList.add('show');
            if (loadingDiv) loadingDiv.style.display = 'none';
            submitBtn.disabled = false;
        }
    });
}

function setupRegisterForm() {
    const registerForm = document.getElementById('registerForm');
    if (!registerForm) {
        console.error('Register form not found');
        return;
    }

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const errorDiv = document.getElementById('errorMessage');
        const loadingDiv = document.getElementById('loadingIndicator');
        const submitBtn = registerForm.querySelector('button[type="submit"]');
        
        errorDiv.classList.remove('show');
        errorDiv.textContent = '';
        if (loadingDiv) loadingDiv.style.display = 'block';
        submitBtn.disabled = true;

        const username = document.getElementById('username').value;
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        console.log('Attempting registration for:', username, email);

        try {
            const response = await authAPI.register(username, email, password);
            console.log('Registration successful:', response);
            setToken(response.token);
            setUser(response.user);
            window.location.href = 'dashboard.html';
        } catch (error) {
            console.error('Registration error:', error);
            errorDiv.textContent = error.message || 'Registration failed. Please check your information.';
            errorDiv.classList.add('show');
            if (loadingDiv) loadingDiv.style.display = 'none';
            submitBtn.disabled = false;
        }
    });
}

