// API Configuration
const API_BASE_URL = (typeof window !== 'undefined' ? window.location.origin : '') + '/api';

// Get auth token from localStorage
function getToken() {
    return localStorage.getItem('token');
}

// Set auth token
function setToken(token) {
    localStorage.setItem('token', token);
}

// Remove auth token
function removeToken() {
    localStorage.removeItem('token');
}

// Get user info
function getUser() {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
}

// Set user info
function setUser(user) {
    localStorage.setItem('user', JSON.stringify(user));
}

// API request helper
async function apiRequest(endpoint, options = {}) {
    const token = getToken();
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };

    if (token) {
        headers['Authorization'] = `Bearer ${token}`;
    }

    try {
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            ...options,
            headers
        });

        let data;
        const contentType = response.headers.get('content-type');
        
        if (contentType && contentType.includes('application/json')) {
            data = await response.json();
        } else {
            const text = await response.text();
            try {
                data = JSON.parse(text);
            } catch {
                throw new Error(text || 'Request failed');
            }
        }

        if (!response.ok) {
            // Handle validation errors
            if (data.errors && Array.isArray(data.errors)) {
                const errorMessages = data.errors.map(e => e.msg || e.message || JSON.stringify(e)).join(', ');
                throw new Error(errorMessages);
            }
            throw new Error(data.message || `Request failed with status ${response.status}`);
        }

        return data;
    } catch (error) {
        console.error('API Error:', error);
        // Re-throw with more context if it's not already an Error object
        if (error instanceof Error) {
            throw error;
        }
        throw new Error(error.message || 'Network error. Please check your connection.');
    }
}

// Auth API
const authAPI = {
    register: async (username, email, password) => {
        return apiRequest('/auth/register', {
            method: 'POST',
            body: JSON.stringify({ username, email, password })
        });
    },
    login: async (email, password) => {
        return apiRequest('/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
    },
    getMe: async () => {
        return apiRequest('/auth/me');
    }
};

// Books API
const booksAPI = {
    getAll: async () => {
        return apiRequest('/books');
    },
    getOne: async (id) => {
        return apiRequest(`/books/${id}`);
    },
    create: async (title, template, mode, page_count) => {
        return apiRequest('/books', {
            method: 'POST',
            body: JSON.stringify({ title, template, mode, page_count })
        });
    },
    update: async (id, data) => {
        return apiRequest(`/books/${id}`, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    },
    delete: async (id) => {
        return apiRequest(`/books/${id}`, {
            method: 'DELETE'
        });
    },
    updatePage: async (bookId, pageNumber, layoutType, content) => {
        return apiRequest(`/books/${bookId}/pages/${pageNumber}`, {
            method: 'PUT',
            body: JSON.stringify({ layout_type: layoutType, content })
        });
    }
};

// Upload API
const uploadAPI = {
    uploadImage: async (file) => {
        const formData = new FormData();
        formData.append('image', file);
        
        const token = getToken();
        const response = await fetch(`${API_BASE_URL}/upload/image`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Upload failed');
        }

        return response.json();
    },
    uploadImages: async (files) => {
        const formData = new FormData();
        files.forEach(file => {
            formData.append('images', file);
        });
        
        const token = getToken();
        const response = await fetch(`${API_BASE_URL}/upload/images`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            body: formData
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'Upload failed');
        }

        return response.json();
    },
    getImages: async () => {
        return apiRequest('/upload/images');
    },
    deleteImage: async (id) => {
        return apiRequest(`/upload/image/${id}`, {
            method: 'DELETE'
        });
    }
};

// PDF API
const pdfAPI = {
    generate: async (bookId) => {
        const token = getToken();
        const response = await fetch(`${API_BASE_URL}/pdf/generate/${bookId}`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.message || 'PDF generation failed');
        }

        // Download PDF
        const blob = await response.blob();
        if (typeof window !== 'undefined' && typeof document !== 'undefined') {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `photobook-${bookId}.pdf`;
            document.body.appendChild(a);
            a.click();
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
        }
    }
};

