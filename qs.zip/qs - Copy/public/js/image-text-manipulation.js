// Image and Text Manipulation Functions - Improved and Reliable Version

// Store active manipulation state to prevent conflicts
const manipulationState = {
    isDragging: false,
    isResizing: false,
    activeElement: null,
    handlers: new Map() // Track handlers per element to prevent duplicates
};

// Clean up all event listeners for an element
function cleanupElementListeners(element, eventType) {
    const key = `${element.dataset.pageNumber}-${element.dataset.slotIndex || element.dataset.imageIndex || element.dataset.textIndex}`;
    const handlers = manipulationState.handlers.get(key);
    if (handlers && handlers[eventType]) {
        handlers[eventType].forEach(({ event, handler, target }) => {
            target.removeEventListener(event, handler);
        });
        delete handlers[eventType];
    }
}

// Store event listeners for cleanup
function storeListener(element, eventType, target, event, handler) {
    const key = `${element.dataset.pageNumber}-${element.dataset.slotIndex || element.dataset.imageIndex || element.dataset.textIndex}`;
    if (!manipulationState.handlers.has(key)) {
        manipulationState.handlers.set(key, {});
    }
    const handlers = manipulationState.handlers.get(key);
    if (!handlers[eventType]) {
        handlers[eventType] = [];
    }
    handlers[eventType].push({ event, handler, target });
}

// Make slot draggable (for slots with images that fill them)
function makeSlotDraggable(slot, pageNumber, slotIndex) {
    // Prevent duplicate listeners
    if (slot.dataset.draggableSetup === 'true') {
        cleanupElementListeners(slot, 'drag');
    }
    slot.dataset.draggableSetup = 'true';
    slot.dataset.pageNumber = pageNumber;
    slot.dataset.slotIndex = slotIndex;
    
    let startX, startY, initialX, initialY;
    let dragThreshold = 5; // Minimum pixels to move before considering it a drag
    let hasMoved = false;
    
    const startDrag = (e) => {
        // Prevent conflicts with other manipulations
        if (manipulationState.isDragging || manipulationState.isResizing) {
            return;
        }
        
        // Don't drag if clicking on controls
        if (e.target.closest('.slot-remove-btn') || 
            e.target.closest('.slot-resize-handle')) {
            return;
        }
        
        hasMoved = false;
        manipulationState.isDragging = true;
        manipulationState.activeElement = slot;
        slot.classList.add('dragging');
        
        const pageElement = slot.closest('.spread-page');
        if (!pageElement) {
            manipulationState.isDragging = false;
            return;
        }
        
        const pageRect = pageElement.getBoundingClientRect();
        const slotRect = slot.getBoundingClientRect();
        
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        // If slot is not absolutely positioned yet, make it so and capture current position
        if (slot.style.position !== 'absolute') {
            slot.style.position = 'absolute';
            slot.style.zIndex = '1000';
            // Get current position in layout
            const currentLeft = slotRect.left - pageRect.left;
            const currentTop = slotRect.top - pageRect.top;
            slot.style.left = currentLeft + 'px';
            slot.style.top = currentTop + 'px';
            initialX = currentLeft;
            initialY = currentTop;
        } else {
            // Already absolutely positioned, use existing position
            initialX = parseInt(slot.style.left) || 0;
            initialY = parseInt(slot.style.top) || 0;
        }
        
        startX = clientX;
        startY = clientY;
        
        e.preventDefault();
        e.stopPropagation();
        
        // Add move and end handlers to document
        document.addEventListener('mousemove', moveHandler);
        document.addEventListener('mouseup', endHandler);
        document.addEventListener('touchmove', moveHandler, { passive: false });
        document.addEventListener('touchend', endHandler);
        
        // Store listeners for cleanup
        storeListener(slot, 'drag', document, 'mousemove', moveHandler);
        storeListener(slot, 'drag', document, 'mouseup', endHandler);
        storeListener(slot, 'drag', document, 'touchmove', moveHandler);
        storeListener(slot, 'drag', document, 'touchend', endHandler);
    };
    
    const moveHandler = (e) => {
        if (!manipulationState.isDragging || manipulationState.activeElement !== slot) return;
        
        const pageElement = slot.closest('.spread-page');
        if (!pageElement) return;
        
        const pageRect = pageElement.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        const deltaX = clientX - startX;
        const deltaY = clientY - startY;
        
        // Check if we've moved enough to consider it dragging
        if (!hasMoved && (Math.abs(deltaX) > dragThreshold || Math.abs(deltaY) > dragThreshold)) {
            hasMoved = true;
        }
        
        if (!hasMoved) return;
        
        const newX = Math.max(0, Math.min(initialX + deltaX, pageElement.offsetWidth - slot.offsetWidth));
        const newY = Math.max(0, Math.min(initialY + deltaY, pageElement.offsetHeight - slot.offsetHeight));
        
        slot.style.left = newX + 'px';
        slot.style.top = newY + 'px';
        
        e.preventDefault();
        e.stopPropagation();
    };
    
    const endHandler = (e) => {
        if (!manipulationState.isDragging || manipulationState.activeElement !== slot) return;
        
        // Only process as drag if we actually moved
        if (hasMoved) {
            manipulationState.isDragging = false;
            slot.classList.remove('dragging');
            
            // Save position
            if (typeof pages !== 'undefined' && typeof savePage !== 'undefined') {
                const page = pages.find(p => p.page_number === pageNumber);
                if (page) {
                    const content = typeof page.content === 'string' 
                        ? JSON.parse(page.content) 
                        : page.content;
                    
                    if (content.images && content.images[slotIndex]) {
                        const currentLeft = parseInt(slot.style.left) || 0;
                        const currentTop = parseInt(slot.style.top) || 0;
                        
                        content.images[slotIndex].x = currentLeft;
                        content.images[slotIndex].y = currentTop;
                        content.images[slotIndex].positioned = true;
                        
                        if (typeof savePage === 'function') {
                            savePage(pageNumber);
                        }
                    }
                }
            }
        } else {
            // Just a click, not a drag - allow click handler to fire
            manipulationState.isDragging = false;
            slot.classList.remove('dragging');
        }
        
        manipulationState.activeElement = null;
        
        // Remove event listeners
        document.removeEventListener('mousemove', moveHandler);
        document.removeEventListener('mouseup', endHandler);
        document.removeEventListener('touchmove', moveHandler);
        document.removeEventListener('touchend', endHandler);
    };
    
    // Mouse events - use mousedown (not click) to avoid conflicts
    slot.addEventListener('mousedown', startDrag);
    storeListener(slot, 'drag', slot, 'mousedown', startDrag);
    
    // Touch events
    slot.addEventListener('touchstart', startDrag, { passive: false });
    storeListener(slot, 'drag', slot, 'touchstart', startDrag);
}

// Make slot resizable (for slots with images that fill them)
function makeSlotResizable(slot, pageNumber, slotIndex) {
    const resizeHandle = slot.querySelector('.slot-resize-handle');
    if (!resizeHandle) return;
    
    // Prevent duplicate listeners
    if (slot.dataset.resizableSetup === 'true') {
        cleanupElementListeners(slot, 'resize');
    }
    slot.dataset.resizableSetup = 'true';
    slot.dataset.pageNumber = pageNumber;
    slot.dataset.slotIndex = slotIndex;
    
    let startX, startY, startWidth, startHeight;
    
    const startResize = (e) => {
        // Prevent conflicts
        if (manipulationState.isDragging || manipulationState.isResizing) {
            return;
        }
        
        e.stopPropagation();
        e.preventDefault();
        
        // Prevent default touch behaviors (scrolling, zooming)
        if (e.touches) {
            e.preventDefault();
        }
        
        manipulationState.isResizing = true;
        manipulationState.activeElement = slot;
        
        // Keep resize handle visible during resize
        resizeHandle.style.display = 'block';
        
        // If slot is not absolutely positioned yet, make it so when resizing
        if (slot.style.position !== 'absolute') {
            slot.style.position = 'absolute';
            slot.style.zIndex = '1000';
            // Get current position in layout
            const pageElement = slot.closest('.spread-page');
            if (pageElement) {
                const pageRect = pageElement.getBoundingClientRect();
                const slotRect = slot.getBoundingClientRect();
                slot.style.left = (slotRect.left - pageRect.left) + 'px';
                slot.style.top = (slotRect.top - pageRect.top) + 'px';
            }
        }
        
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        startX = clientX;
        startY = clientY;
        startWidth = parseInt(slot.style.width) || slot.offsetWidth;
        startHeight = parseInt(slot.style.height) || slot.offsetHeight;
        
        // Add move and end handlers
        document.addEventListener('mousemove', moveHandler);
        document.addEventListener('mouseup', endHandler);
        document.addEventListener('touchmove', moveHandler, { passive: false });
        document.addEventListener('touchend', endHandler);
        
        storeListener(slot, 'resize', document, 'mousemove', moveHandler);
        storeListener(slot, 'resize', document, 'mouseup', endHandler);
        storeListener(slot, 'resize', document, 'touchmove', moveHandler);
        storeListener(slot, 'resize', document, 'touchend', endHandler);
    };
    
    const moveHandler = (e) => {
        if (!manipulationState.isResizing || manipulationState.activeElement !== slot) return;
        
        // Always prevent default for touch events during resize
        if (e.touches) {
            e.preventDefault();
        }
        
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        const deltaX = clientX - startX;
        const deltaY = clientY - startY;
        
        const pageElement = slot.closest('.spread-page');
        const maxWidth = pageElement ? pageElement.offsetWidth : 800;
        const maxHeight = pageElement ? pageElement.offsetHeight : 800;
        
        const newWidth = Math.max(100, Math.min(startWidth + deltaX, maxWidth));
        const newHeight = Math.max(100, Math.min(startHeight + deltaY, maxHeight));
        
        slot.style.width = newWidth + 'px';
        slot.style.height = newHeight + 'px';
        
        e.preventDefault();
        e.stopPropagation();
    };
    
    const endHandler = (e) => {
        if (!manipulationState.isResizing || manipulationState.activeElement !== slot) return;
        
        if (e && e.touches) {
            e.preventDefault();
        }
        
        manipulationState.isResizing = false;
        manipulationState.activeElement = null;
        
        // Save size
        if (typeof pages !== 'undefined' && typeof savePage !== 'undefined') {
            const page = pages.find(p => p.page_number === pageNumber);
            if (page) {
                const content = typeof page.content === 'string' 
                    ? JSON.parse(page.content) 
                    : page.content;
                
                if (content.images && content.images[slotIndex]) {
                    content.images[slotIndex].width = parseInt(slot.style.width);
                    content.images[slotIndex].height = parseInt(slot.style.height);
                    if (typeof savePage === 'function') {
                        savePage(pageNumber);
                    }
                }
            }
        }
        
        // Remove event listeners
        document.removeEventListener('mousemove', moveHandler);
        document.removeEventListener('mouseup', endHandler);
        document.removeEventListener('touchmove', moveHandler);
        document.removeEventListener('touchend', endHandler);
    };
    
    // Mouse events
    resizeHandle.addEventListener('mousedown', startResize);
    storeListener(slot, 'resize', resizeHandle, 'mousedown', startResize);
    
    // Touch events
    resizeHandle.addEventListener('touchstart', startResize, { passive: false });
    storeListener(slot, 'resize', resizeHandle, 'touchstart', startResize);
}

// Make text draggable (supports both mouse and touch)
function makeTextDraggable(element, pageNumber, textIndex) {
    // Prevent duplicate listeners
    if (element.dataset.draggableSetup === 'true') {
        cleanupElementListeners(element, 'drag');
    }
    element.dataset.draggableSetup = 'true';
    element.dataset.pageNumber = pageNumber;
    element.dataset.textIndex = textIndex;
    
    let startX, startY, initialX, initialY;
    let dragThreshold = 5;
    let hasMoved = false;
    
    const startDrag = (e) => {
        if (manipulationState.isDragging || manipulationState.isResizing) return;
        
        // Don't drag if clicking on resize handle or if element is being edited
        if (e.target.classList.contains('text-resize-handle') || 
            e.target.closest('.text-resize-handle') ||
            element.contentEditable === 'true' && document.activeElement === element) {
            return;
        }
        
        hasMoved = false;
        manipulationState.isDragging = true;
        manipulationState.activeElement = element;
        element.classList.add('dragging');
        
        const pageElement = element.closest('.spread-page');
        if (!pageElement) {
            manipulationState.isDragging = false;
            return;
        }
        
        const pageRect = pageElement.getBoundingClientRect();
        const elementRect = element.getBoundingClientRect();
        
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        startX = clientX;
        startY = clientY;
        initialX = elementRect.left - pageRect.left;
        initialY = elementRect.top - pageRect.top;
        
        e.preventDefault();
        e.stopPropagation();
        
        document.addEventListener('mousemove', moveHandler);
        document.addEventListener('mouseup', endHandler);
        document.addEventListener('touchmove', moveHandler, { passive: false });
        document.addEventListener('touchend', endHandler);
        
        storeListener(element, 'drag', document, 'mousemove', moveHandler);
        storeListener(element, 'drag', document, 'mouseup', endHandler);
        storeListener(element, 'drag', document, 'touchmove', moveHandler);
        storeListener(element, 'drag', document, 'touchend', endHandler);
    };
    
    const moveHandler = (e) => {
        if (!manipulationState.isDragging || manipulationState.activeElement !== element) return;
        
        const pageElement = element.closest('.spread-page');
        if (!pageElement) return;
        
        const pageRect = pageElement.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        
        const deltaX = clientX - startX;
        const deltaY = clientY - startY;
        
        if (!hasMoved && (Math.abs(deltaX) > dragThreshold || Math.abs(deltaY) > dragThreshold)) {
            hasMoved = true;
        }
        
        if (!hasMoved) return;
        
        const newX = Math.max(0, Math.min(initialX + deltaX, pageElement.offsetWidth - element.offsetWidth));
        const newY = Math.max(0, Math.min(initialY + deltaY, pageElement.offsetHeight - element.offsetHeight));
        
        element.style.left = newX + 'px';
        element.style.top = newY + 'px';
        
        e.preventDefault();
        e.stopPropagation();
    };
    
    const endHandler = () => {
        if (!manipulationState.isDragging || manipulationState.activeElement !== element) return;
        
        manipulationState.isDragging = false;
        manipulationState.activeElement = null;
        element.classList.remove('dragging');
        
        if (hasMoved && typeof pages !== 'undefined' && typeof savePage !== 'undefined') {
            const page = pages.find(p => p.page_number === pageNumber);
            if (page) {
                const content = typeof page.content === 'string' 
                    ? JSON.parse(page.content) 
                    : page.content;
                
                if (content.texts && content.texts[textIndex]) {
                    content.texts[textIndex].x = parseInt(element.style.left) || 0;
                    content.texts[textIndex].y = parseInt(element.style.top) || 0;
                    if (typeof savePage === 'function') {
                        savePage(pageNumber);
                    }
                }
            }
        }
        
        document.removeEventListener('mousemove', moveHandler);
        document.removeEventListener('mouseup', endHandler);
        document.removeEventListener('touchmove', moveHandler);
        document.removeEventListener('touchend', endHandler);
    };
    
    element.addEventListener('mousedown', startDrag);
    storeListener(element, 'drag', element, 'mousedown', startDrag);
    
    // For touch, wait to see if it's a tap (selection) or drag
    let touchStartData = null;
    element.addEventListener('touchstart', (e) => {
        if (e.touches.length === 1) {
            touchStartData = {
                x: e.touches[0].clientX,
                y: e.touches[0].clientY,
                time: Date.now()
            };
            // Don't start drag immediately - wait to see if user moves finger
        }
    }, { passive: true });
    
    // Start drag only if touch moves significantly (not just a tap)
    element.addEventListener('touchmove', (e) => {
        if (touchStartData && e.touches.length === 1) {
            const deltaX = Math.abs(e.touches[0].clientX - touchStartData.x);
            const deltaY = Math.abs(e.touches[0].clientY - touchStartData.y);
            const moveDistance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
            
            // If moved more than 10px, it's a drag - start dragging
            if (moveDistance > 10) {
                touchStartData = null; // Clear to prevent multiple triggers
                startDrag(e);
            }
        }
    }, { passive: false });
    
    // Clear touch data on touch end
    element.addEventListener('touchend', () => {
        touchStartData = null;
    }, { passive: true });
}

// Make text resizable (supports both mouse and touch)
function makeTextResizable(element, pageNumber, textIndex) {
    const resizeHandle = element.querySelector('.text-resize-handle');
    if (!resizeHandle) return;
    
    if (element.dataset.resizableSetup === 'true') {
        cleanupElementListeners(element, 'resize');
    }
    element.dataset.resizableSetup = 'true';
    element.dataset.pageNumber = pageNumber;
    element.dataset.textIndex = textIndex;
    
    let startX, startFontSize;
    
    const startResize = (e) => {
        if (manipulationState.isDragging || manipulationState.isResizing) return;
        
        e.stopPropagation();
        e.preventDefault();
        
        manipulationState.isResizing = true;
        manipulationState.activeElement = element;
        
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        startX = clientX;
        startFontSize = parseInt(element.style.fontSize) || 16;
        
        document.addEventListener('mousemove', moveHandler);
        document.addEventListener('mouseup', endHandler);
        document.addEventListener('touchmove', moveHandler, { passive: false });
        document.addEventListener('touchend', endHandler);
        
        storeListener(element, 'resize', document, 'mousemove', moveHandler);
        storeListener(element, 'resize', document, 'mouseup', endHandler);
        storeListener(element, 'resize', document, 'touchmove', moveHandler);
        storeListener(element, 'resize', document, 'touchend', endHandler);
    };
    
    const moveHandler = (e) => {
        if (!manipulationState.isResizing || manipulationState.activeElement !== element) return;
        
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const deltaX = clientX - startX;
        const scale = 1 + (deltaX / 100);
        const newFontSize = Math.max(8, Math.min(72, startFontSize * scale));
        
        element.style.fontSize = newFontSize + 'px';
        
        e.preventDefault();
        e.stopPropagation();
    };
    
    const endHandler = () => {
        if (!manipulationState.isResizing || manipulationState.activeElement !== element) return;
        
        manipulationState.isResizing = false;
        manipulationState.activeElement = null;
        
        if (typeof pages !== 'undefined' && typeof savePage !== 'undefined') {
            const page = pages.find(p => p.page_number === pageNumber);
            if (page) {
                const content = typeof page.content === 'string' 
                    ? JSON.parse(page.content) 
                    : page.content;
                
                if (content.texts && content.texts[textIndex]) {
                    content.texts[textIndex].fontSize = parseInt(element.style.fontSize);
                    if (typeof savePage === 'function') {
                        savePage(pageNumber);
                    }
                }
            }
        }
        
        document.removeEventListener('mousemove', moveHandler);
        document.removeEventListener('mouseup', endHandler);
        document.removeEventListener('touchmove', moveHandler);
        document.removeEventListener('touchend', endHandler);
    };
    
    resizeHandle.addEventListener('mousedown', startResize);
    storeListener(element, 'resize', resizeHandle, 'mousedown', startResize);
    
    resizeHandle.addEventListener('touchstart', startResize, { passive: false });
    storeListener(element, 'resize', resizeHandle, 'touchstart', startResize);
}

// Rotate image
function rotateImage(pageNumber, imageIndex) {
    const page = pages.find(p => p.page_number === pageNumber);
    const content = typeof page.content === 'string' 
        ? JSON.parse(page.content) 
        : page.content;
    
    if (content.images && content.images[imageIndex]) {
        const currentRotation = content.images[imageIndex].rotation || 0;
        const newRotation = (currentRotation + 90) % 360;
        content.images[imageIndex].rotation = newRotation;
        
        const element = document.querySelector(`.editable-image[data-page-number="${pageNumber}"][data-image-index="${imageIndex}"]`);
        if (element) {
            const img = element.querySelector('img');
            img.style.transform = `rotate(${newRotation}deg)`;
        }
        
        savePage(pageNumber);
    }
}
