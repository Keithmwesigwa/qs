// Wait for api.js to load and DOM to be ready
function checkAuth() {
    if (typeof window === 'undefined') {
        // Not in browser environment, wait
        setTimeout(checkAuth, 100);
        return;
    }
    
    if (typeof getToken === 'undefined') {
        setTimeout(checkAuth, 100);
        return;
    }
    
    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                if (!getToken()) {
                    window.location.href = 'login.html';
                    return;
                }
                initializeDashboard();
            });
        } else {
            if (!getToken()) {
                window.location.href = 'login.html';
                return;
            }
            initializeDashboard();
        }
    }
}

// Initialize dashboard
let books = [];
let currentUser = null;

function initializeDashboard() {
    // Wait for DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setupDashboard();
        });
    } else {
        setupDashboard();
    }
}

function setupDashboard() {
    // Load data
    loadUserInfo();
    loadBooks();
    
    // Setup event listeners
    setupEventListeners();
}

// Load user info
async function loadUserInfo() {
    try {
        const response = await authAPI.getMe();
        currentUser = response.user;
        document.getElementById('userInfo').textContent = `Welcome, ${currentUser.username}!`;
    } catch (error) {
        console.error('Failed to load user info:', error);
        if (error.message.includes('token')) {
            removeToken();
            window.location.href = 'login.html';
        }
    }
}

// Load books
async function loadBooks() {
    try {
        const response = await booksAPI.getAll();
        books = response.books;
        renderBooks();
    } catch (error) {
        console.error('Failed to load books:', error);
    }
}

// Render books
function renderBooks() {
    const booksList = document.getElementById('booksList');
    
    if (books.length === 0) {
        booksList.innerHTML = `
            <div class="empty-state" style="grid-column: 1 / -1;">
                <div class="empty-state-icon">📖</div>
                <h3>No books yet</h3>
                <p>Create your first photo book to get started</p>
                <button id="createFirstBookBtn" class="btn btn-primary">Create Book</button>
            </div>
        `;
        
        // Add event listener for empty state button
        const createFirstBookBtn = document.getElementById('createFirstBookBtn');
        if (createFirstBookBtn) {
            createFirstBookBtn.addEventListener('click', () => {
                const createBookBtn = document.getElementById('createBookBtn');
                if (createBookBtn) createBookBtn.click();
            });
        }
        return;
    }

    booksList.innerHTML = books.map(book => `
        <div class="book-card" data-book-id="${book.id}">
            <div class="book-cover-mockup">
                <div class="book-cover-title">${book.title}</div>
            </div>
            <div class="book-card-content">
                <h3>${book.title}</h3>
                <div class="book-meta">
                    <p><strong>Theme:</strong> ${book.template.charAt(0).toUpperCase() + book.template.slice(1)}</p>
                    <p><strong>Pages:</strong> ${book.page_count || 25} pages</p>
                    <p><strong>Status:</strong> <span class="book-status-badge ${book.status}">${book.status}</span></p>
                </div>
                <div class="book-actions">
                    <button class="btn btn-primary edit-book" data-book-id="${book.id}">Edit</button>
                    <button class="btn btn-secondary preview-book" data-book-id="${book.id}">Preview</button>
                    ${book.status === 'completed' ? `<button class="btn btn-success download-pdf" data-book-id="${book.id}">Download</button>` : ''}
                    <button class="btn btn-danger delete-book" data-book-id="${book.id}">Delete</button>
                </div>
            </div>
        </div>
    `).join('');

    // Add event listeners
    document.querySelectorAll('.edit-book').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const bookId = e.target.dataset.bookId;
            const book = books.find(b => b.id == bookId);
            
            // For smart mode books, check if they've been generated
            if (book.mode === 'smart') {
                try {
                    // Fetch full book data to check if it has generated content
                    const response = await booksAPI.getOne(bookId);
                    const fullBook = response.book;
                    
                    // Check if book has pages with images (already generated)
                    const hasGeneratedContent = fullBook.pages && fullBook.pages.some(page => {
                        try {
                            const content = typeof page.content === 'string' 
                                ? JSON.parse(page.content) 
                                : page.content || {};
                            return content.images && content.images.length > 0;
                        } catch (e) {
                            return false;
                        }
                    });
                    
                    // If generated, go to studio; otherwise go to smart mode for generation
                    if (hasGeneratedContent) {
                        window.location.href = `manual-mode.html?bookId=${bookId}`;
                    } else {
                        window.location.href = `smart-mode.html?bookId=${bookId}`;
                    }
                } catch (error) {
                    console.error('Failed to check book status:', error);
                    // Fallback to smart mode on error
                    window.location.href = `smart-mode.html?bookId=${bookId}`;
                }
            } else {
                window.location.href = `manual-mode.html?bookId=${bookId}`;
            }
        });
    });

    document.querySelectorAll('.preview-book').forEach(btn => {
        btn.addEventListener('click', (e) => {
            const bookId = e.target.dataset.bookId;
            window.location.href = `preview.html?bookId=${bookId}`;
        });
    });

    document.querySelectorAll('.download-pdf').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const bookId = e.target.dataset.bookId;
            try {
                await pdfAPI.generate(bookId);
            } catch (error) {
                alert('Failed to generate PDF: ' + error.message);
            }
        });
    });

    document.querySelectorAll('.delete-book').forEach(btn => {
        btn.addEventListener('click', async (e) => {
            const bookId = e.target.dataset.bookId;
            if (confirm('Are you sure you want to delete this book?')) {
                try {
                    await booksAPI.delete(bookId);
                    loadBooks();
                } catch (error) {
                    alert('Failed to delete book: ' + error.message);
                }
            }
        });
    });
}

// Setup event listeners
function setupEventListeners() {
    // Create book modal
    const createBookModal = document.getElementById('createBookModal');
    const createBookBtn = document.getElementById('createBookBtn');
    const closeModal = document.querySelector('.close');

    if (createBookBtn && createBookModal) {
        createBookBtn.addEventListener('click', () => {
            createBookModal.style.display = 'block';
        });
    }

    if (closeModal) {
        closeModal.addEventListener('click', () => {
            createBookModal.style.display = 'none';
        });
    }

    if (createBookModal) {
        window.addEventListener('click', (e) => {
            if (e.target === createBookModal) {
                createBookModal.style.display = 'none';
            }
        });
    }

    // Handle template selection
    const templateCards = document.querySelectorAll('.template-selector-card');
    const hiddenTemplateInput = document.getElementById('bookTemplate');
    
    templateCards.forEach(card => {
        const radio = card.querySelector('input[type="radio"]');
        if (radio) {
            radio.addEventListener('change', () => {
                if (radio.checked) {
                    hiddenTemplateInput.value = radio.value;
                }
            });
        }
    });

    // Handle create book form
    const createBookForm = document.getElementById('createBookForm');
    if (createBookForm) {
        createBookForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const title = document.getElementById('bookTitle').value;
            const template = document.getElementById('bookTemplate').value || document.querySelector('input[name="template"]:checked')?.value;
            const mode = document.querySelector('input[name="mode"]:checked').value;
            const page_count = parseInt(document.getElementById('pageCount').value);

            if (!template) {
                alert('Please select a template');
                return;
            }

            try {
                const response = await booksAPI.create(title, template, mode, page_count);
                createBookModal.style.display = 'none';
                
                if (mode === 'smart') {
                    window.location.href = `smart-mode.html?bookId=${response.bookId}`;
                } else {
                    window.location.href = `manual-mode.html?bookId=${response.bookId}`;
                }
            } catch (error) {
                alert('Failed to create book: ' + error.message);
            }
        });
    }

    // Logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            removeToken();
            localStorage.removeItem('user');
            window.location.href = 'login.html';
        });
    }
}

// Initialize
checkAuth();

