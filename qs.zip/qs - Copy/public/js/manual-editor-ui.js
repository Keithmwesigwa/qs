// Manual Editor UI Interactions

document.addEventListener('DOMContentLoaded', () => {
    // Mobile menu handlers
    const pagesMenuBtn = document.getElementById('pagesMenuBtn');
    const toolsMenuBtn = document.getElementById('toolsMenuBtn');
    const pagesSidebar = document.querySelector('.pages-sidebar');
    const toolsSidebar = document.querySelector('.tools-sidebar');
    
    // Show/hide mobile menu buttons based on screen size
    function updateMobileMenuVisibility() {
        const isMobile = window.innerWidth <= 1024;
        if (pagesMenuBtn) pagesMenuBtn.style.display = isMobile ? 'block' : 'none';
        if (toolsMenuBtn) toolsMenuBtn.style.display = isMobile ? 'block' : 'none';
    }
    
    // Toggle sidebars on mobile
    if (pagesMenuBtn && pagesSidebar) {
        pagesMenuBtn.addEventListener('click', () => {
            pagesSidebar.classList.toggle('open');
            if (toolsSidebar) toolsSidebar.classList.remove('open');
        });
    }
    
    if (toolsMenuBtn && toolsSidebar) {
        toolsMenuBtn.addEventListener('click', () => {
            toolsSidebar.classList.toggle('open');
            if (pagesSidebar) pagesSidebar.classList.remove('open');
        });
    }
    
    // Close sidebars when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 1024) {
            if (pagesSidebar && !pagesSidebar.contains(e.target) && !pagesMenuBtn.contains(e.target)) {
                pagesSidebar.classList.remove('open');
            }
            if (toolsSidebar && !toolsSidebar.contains(e.target) && !toolsMenuBtn.contains(e.target)) {
                toolsSidebar.classList.remove('open');
            }
        }
    });
    
    // Update on resize
    window.addEventListener('resize', updateMobileMenuVisibility);
    updateMobileMenuVisibility();
    
    // Mobile Floating Action Button
    const mobileFab = document.getElementById('mobileFab');
    const mobileFabMenu = document.getElementById('mobileFabMenu');
    const mobilePagesBtn = document.getElementById('mobilePagesBtn');
    const mobileImagesBtn = document.getElementById('mobileImagesBtn');
    const mobileTextBtn = document.getElementById('mobileTextBtn');
    const mobileLayoutsBtn = document.getElementById('mobileLayoutsBtn');
    
    function updateMobileFabVisibility() {
        const isMobile = window.innerWidth <= 768;
        if (mobileFab) {
            mobileFab.style.display = isMobile ? 'flex' : 'none';
        }
    }
    
    if (mobileFab && mobileFabMenu) {
        mobileFab.addEventListener('click', () => {
            mobileFabMenu.classList.toggle('open');
            // Close sidebars when opening FAB menu
            if (pagesSidebar) pagesSidebar.classList.remove('open');
            if (toolsSidebar) toolsSidebar.classList.remove('open');
        });
    }
    
    if (mobilePagesBtn) {
        mobilePagesBtn.addEventListener('click', () => {
            if (pagesSidebar) {
                pagesSidebar.classList.toggle('open');
                if (toolsSidebar) toolsSidebar.classList.remove('open');
            }
            if (mobileFabMenu) mobileFabMenu.classList.remove('open');
        });
    }
    
    if (mobileImagesBtn) {
        mobileImagesBtn.addEventListener('click', () => {
            // Switch to images tab
            const imagesTab = document.querySelector('.tool-tab[data-tool="images"]');
            if (imagesTab) {
                imagesTab.click();
            }
            if (toolsSidebar) {
                toolsSidebar.classList.add('open');
                if (pagesSidebar) pagesSidebar.classList.remove('open');
            }
            if (mobileFabMenu) mobileFabMenu.classList.remove('open');
        });
    }
    
    if (mobileTextBtn) {
        mobileTextBtn.addEventListener('click', () => {
            // Switch to text tab
            const textTab = document.querySelector('.tool-tab[data-tool="text"]');
            if (textTab) {
                textTab.click();
            }
            if (toolsSidebar) {
                toolsSidebar.classList.add('open');
                if (pagesSidebar) pagesSidebar.classList.remove('open');
            }
            if (mobileFabMenu) mobileFabMenu.classList.remove('open');
        });
    }
    
    if (mobileLayoutsBtn) {
        mobileLayoutsBtn.addEventListener('click', () => {
            // Switch to layouts tab
            const layoutsTab = document.querySelector('.tool-tab[data-tool="layouts"]');
            if (layoutsTab) {
                layoutsTab.click();
            }
            if (toolsSidebar) {
                toolsSidebar.classList.add('open');
                if (pagesSidebar) pagesSidebar.classList.remove('open');
            }
            if (mobileFabMenu) mobileFabMenu.classList.remove('open');
        });
    }
    
    // Close FAB menu when clicking outside
    document.addEventListener('click', (e) => {
        if (mobileFabMenu && mobileFabMenu.classList.contains('open')) {
            if (!mobileFab.contains(e.target) && !mobileFabMenu.contains(e.target)) {
                mobileFabMenu.classList.remove('open');
            }
        }
    });
    
    window.addEventListener('resize', updateMobileFabVisibility);
    updateMobileFabVisibility();
    
    // Tool tabs switching
    const toolTabs = document.querySelectorAll('.tool-tab');
    const toolPanels = document.querySelectorAll('.tool-panel');
    
    toolTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTool = tab.dataset.tool;
            
            // Update active tab
            toolTabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Update active panel
            toolPanels.forEach(p => p.classList.remove('active'));
            const targetPanel = document.getElementById(targetTool + 'Panel');
            if (targetPanel) {
                targetPanel.classList.add('active');
            }
            
            // Handle specific tool actions
            if (targetTool === 'images') {
                // Images tab clicked - ensure images are loaded
                console.log('Images tab clicked, loading images...');
                // Use window.renderMyImages with the myImagesArray from manual-mode.js
                if (window.myImagesArray && window.renderMyImages) {
                    console.log('Rendering', window.myImagesArray.length, 'images from myImagesArray');
                    window.renderMyImages(window.myImagesArray);
                } else if (window.loadMyImagesHandler) {
                    window.loadMyImagesHandler();
                } else if (window.loadMyImages) {
                    window.loadMyImages();
                } else {
                    console.error('loadMyImages function not found');
                }
            }
        });
    });
    
    // Layout card selection
    const layoutCards = document.querySelectorAll('.layout-card');
    
    layoutCards.forEach(card => {
        card.addEventListener('click', () => {
            layoutCards.forEach(c => c.classList.remove('active'));
            card.classList.add('active');
            
            const layout = card.dataset.layout;
            // Call the layout handler directly
            if (window.changePageLayout) {
                window.changePageLayout(layout);
            } else if (window.setLayoutHandler && window.currentLayoutHandler) {
                window.currentLayoutHandler(layout);
            }
        });
    });
    
    // Upload trigger
    const uploadTrigger = document.getElementById('uploadTrigger');
    const imageInput = document.getElementById('imageInput');
    
    if (uploadTrigger && imageInput) {
        uploadTrigger.addEventListener('click', () => {
            imageInput.click();
        });
        
        // Drag and drop
        uploadTrigger.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadTrigger.style.borderColor = '#667eea';
            uploadTrigger.style.background = '#f0f4ff';
        });
        
        uploadTrigger.addEventListener('dragleave', () => {
            uploadTrigger.style.borderColor = '#d1d5db';
            uploadTrigger.style.background = '#f9fafb';
        });
        
        uploadTrigger.addEventListener('drop', async (e) => {
            e.preventDefault();
            uploadTrigger.style.borderColor = '#d1d5db';
            uploadTrigger.style.background = '#f9fafb';
            
            const files = Array.from(e.dataTransfer.files);
            if (files.length > 0) {
                // Upload files directly
                for (const file of files) {
                    try {
                        if (window.uploadImageFile) {
                            await window.uploadImageFile(file);
                        } else {
                            // Fallback: trigger file input
                            const dataTransfer = new DataTransfer();
                            dataTransfer.items.add(file);
                            imageInput.files = dataTransfer.files;
                            imageInput.dispatchEvent(new Event('change', { bubbles: true }));
                        }
                    } catch (error) {
                        console.error('Failed to upload image:', error);
                        alert('Failed to upload image: ' + error.message);
                    }
                }
            }
        });
    }
    
    // Add text block button
    const addTextBlockBtn = document.getElementById('addTextBlockBtn');
    const textModal = document.getElementById('textEditorModal');
    
    if (addTextBlockBtn && textModal) {
        addTextBlockBtn.addEventListener('click', () => {
            textModal.style.display = 'block';
        });
    }
    
    // Header buttons
    const saveDraftBtn = document.getElementById('saveDraftBtn');
    const previewBtn = document.getElementById('previewBtn');
    const exportPdfBtn = document.getElementById('exportPdfBtn');
    
    if (saveDraftBtn) {
        saveDraftBtn.addEventListener('click', () => {
            if (window.saveDraftHandler) {
                window.saveDraftHandler();
            }
        });
    }
    
    if (previewBtn) {
        previewBtn.addEventListener('click', () => {
            if (window.previewHandler) {
                window.previewHandler();
            }
        });
    }
    
    if (exportPdfBtn) {
        exportPdfBtn.addEventListener('click', () => {
            if (window.exportPdfHandler) {
                window.exportPdfHandler();
            }
        });
    }
    
    // Close modal
    const closeModal = document.querySelector('.modal .close');
    if (closeModal) {
        closeModal.addEventListener('click', () => {
            document.querySelectorAll('.modal').forEach(modal => {
                modal.style.display = 'none';
            });
        });
    }
    
    // Click outside modal to close
    window.addEventListener('click', (e) => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });
});

// Export functions for manual-mode.js
window.setLayoutHandler = function(handler) {
    window.currentLayoutHandler = handler;
};

window.setSaveDraftHandler = function(handler) {
    window.saveDraftHandler = handler;
};

window.setPreviewHandler = function(handler) {
    window.previewHandler = handler;
};

window.setExportPdfHandler = function(handler) {
    window.exportPdfHandler = handler;
};

window.updatePagesList = function(pages, currentPage, onPageClick) {
    const pagesList = document.getElementById('pagesList');
    if (!pagesList) return;
    
    pagesList.innerHTML = '';
    
    pages.forEach(page => {
        const thumbnail = document.createElement('div');
        thumbnail.className = 'page-thumbnail';
        if (page.page_number === currentPage) {
            thumbnail.classList.add('active');
        }
        
        const number = document.createElement('div');
        number.className = 'page-thumbnail-number';
        number.textContent = page.page_number;
        thumbnail.appendChild(number);
        
        thumbnail.addEventListener('click', () => {
            onPageClick(page.page_number);
        });
        
        pagesList.appendChild(thumbnail);
    });
};

window.setCurrentPageDisplay = function(text) {
    // This is handled by updatePagesList now
};

window.setTotalPagesCount = function(count) {
    const totalPagesCount = document.getElementById('totalPagesCount');
    if (totalPagesCount) {
        totalPagesCount.textContent = count;
    }
};

// Override window.renderMyImages to use the myImages array from manual-mode.js
window.renderMyImages = function(images, onImageSelect) {
    // If images parameter is provided, use it, otherwise use the global myImages array
    const imagesToRender = images !== undefined ? images : (window.myImagesArray || []);
    
    const container = document.getElementById('myImages');
    if (!container) {
        console.error('myImages container not found');
        return;
    }
    
    console.log('window.renderMyImages called with:', imagesToRender?.length || 0, 'images');
    console.log('images parameter:', images);
    console.log('Using myImagesArray:', window.myImagesArray?.length || 0);
    
    if (!imagesToRender || !Array.isArray(imagesToRender) || imagesToRender.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #9ca3af; padding: 20px;">No images uploaded yet</p>';
        return;
    }
    
    container.innerHTML = imagesToRender.map((img, index) => {
        const imageUrl = img.cloudinary_url || img.url;
        const imageId = img.id || img.cloudinary_id || index;
        console.log(`Rendering image ${index}:`, imageUrl);
        return `
            <div class="my-image-item" data-image-id="${imageId}" data-image-url="${imageUrl}">
                <img src="${imageUrl}" alt="Image" onerror="console.error('Failed to load image:', this.src)">
            </div>
        `;
    }).join('');
    
    // Add click handlers
    document.querySelectorAll('.my-image-item').forEach(item => {
        item.addEventListener('click', () => {
            document.querySelectorAll('.my-image-item').forEach(i => i.classList.remove('selected'));
            item.classList.add('selected');
            
            const selectedImg = {
                id: item.dataset.imageId,
                url: item.dataset.imageUrl,
                cloudinary_url: item.dataset.imageUrl
            };
            
            console.log('Image selected:', selectedImg);
            
            // Set the global selectedImage variable (used by addImageToSlot)
            if (typeof window !== 'undefined' && window.setSelectedImage) {
                window.setSelectedImage(selectedImg);
            } else if (typeof selectedImage !== 'undefined') {
                // Try to set it directly if we can access the variable
                try {
                    selectedImage = selectedImg;
                } catch (e) {
                    console.warn('Could not set selectedImage directly:', e);
                }
            }
            
            if (onImageSelect) {
                onImageSelect(selectedImg);
            }
        });
    });
    
    console.log('Images rendered successfully');
};

