// Wait for api.js to load and DOM to be ready
function checkAuth() {
    if (typeof window === 'undefined') {
        // Not in browser environment, wait
        setTimeout(checkAuth, 100);
        return;
    }
    
    if (typeof getToken === 'undefined') {
        setTimeout(checkAuth, 100);
        return;
    }
    
    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                if (!getToken()) {
                    window.location.href = 'login.html';
                    return;
                }
                initializePreview();
            });
        } else {
            if (!getToken()) {
                window.location.href = 'login.html';
                return;
            }
            initializePreview();
        }
    }
}

// Get book ID from URL
let bookId = null;
if (typeof window !== 'undefined' && typeof URLSearchParams !== 'undefined') {
    const urlParams = new URLSearchParams(window.location.search);
    bookId = urlParams.get('bookId');
}

function initializePreview() {
    if (!bookId) {
        if (typeof window !== 'undefined') {
            window.location.href = 'dashboard.html';
        }
        return;
    }
    
    // Wait for DOM
    if (typeof document !== 'undefined') {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                setupPreview();
            });
        } else {
            setupPreview();
        }
    }
}

function setupPreview() {
    loadBook();
    
    // Navigation
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            if (currentPageIndex > 0) {
                currentPageIndex = Math.max(0, currentPageIndex - 2);
                renderPages();
            }
        });
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', () => {
            if (currentPageIndex < pages.length - 2) {
                currentPageIndex = Math.min(pages.length - 2, currentPageIndex + 2);
                renderPages();
            }
        });
    }
}


let book = null;
let pages = [];
let currentPageIndex = 0;
let viewMode = 'spread'; // 'spread' or 'single'

// Load book data
async function loadBook() {
    try {
        const response = await booksAPI.getOne(bookId);
        book = response.book;
        pages = book.pages || [];
        
        document.getElementById('bookTitle').textContent = book.title;
        document.getElementById('bookInfo').textContent = 
            `${book.template} • ${book.mode} • ${book.page_count || pages.length} pages`;
        
        renderPages();
    } catch (error) {
        console.error('Failed to load book:', error);
        alert('Failed to load book');
        window.location.href = 'dashboard.html';
    }
}

// Render pages
function renderPages() {
    const container = document.getElementById('previewContainer');
    const pageCount = pages.length;
    
    if (pageCount === 0) {
        container.innerHTML = '<p style="text-align: center; color: #666; padding: 40px;">No pages in this book yet.</p>';
        return;
    }

    // Show two pages side by side (spread view)
    const currentPage = pages[currentPageIndex];
    const nextPage = pages[currentPageIndex + 1];
    
    container.innerHTML = '';
    
    const spread = document.createElement('div');
    spread.className = 'page-spread';
    
    // Left page
    const leftPage = createPagePreview(currentPage);
    spread.appendChild(leftPage);
    
    // Right page (if exists)
    if (nextPage) {
        const rightPage = createPagePreview(nextPage);
        spread.appendChild(rightPage);
    } else {
        // Empty right page
        const emptyPage = document.createElement('div');
        emptyPage.className = 'page-preview';
        emptyPage.style.background = '#f7fafc';
        spread.appendChild(emptyPage);
    }
    
    container.appendChild(spread);
    
    // Update page indicator
    document.getElementById('pageIndicator').textContent = 
        `Pages ${currentPageIndex + 1}-${Math.min(currentPageIndex + 2, pageCount)} of ${pageCount}`;
    
    // Update navigation buttons
    document.getElementById('prevBtn').disabled = currentPageIndex === 0;
    document.getElementById('nextBtn').disabled = currentPageIndex >= pageCount - 2;
}

// Create page preview element
function createPagePreview(page) {
    const pageDiv = document.createElement('div');
    pageDiv.className = 'page-preview';
    
    const pageNumber = document.createElement('div');
    pageNumber.className = 'page-number';
    pageNumber.textContent = `Page ${page.page_number}`;
    pageDiv.appendChild(pageNumber);
    
    const content = typeof page.content === 'string' 
        ? JSON.parse(page.content) 
        : page.content || {};
    
    const pageContent = document.createElement('div');
    pageContent.className = `page-content layout-${page.layout_type || 'single'}`;
    pageContent.style.position = 'relative';
    
    // Apply background color if set
    if (content.backgroundColor) {
        pageContent.style.backgroundColor = content.backgroundColor;
    } else {
        pageContent.style.backgroundColor = '#ffffff';
    }
    
    const layout = page.layout_type || 'single';
    
    // For fullspread or absolutely positioned images, render with absolute positioning
    // For layout-based images (single, double, triple, quad), render in slots
    if (layout === 'fullspread' || (content.images && content.images.some(img => img.x !== undefined || img.y !== undefined))) {
        // Render with absolute positioning
        if (content.images && content.images.length > 0) {
            content.images.forEach((img, index) => {
                if (img && (img.url || img.cloudinary_url)) {
                    const imgEl = document.createElement('img');
                    const imageUrl = img.url || img.cloudinary_url;
                    imgEl.src = imageUrl;
                    imgEl.alt = `Page ${page.page_number} image ${index + 1}`;
                    imgEl.style.position = 'absolute';
                    imgEl.style.objectFit = 'cover';
                    
                    // Apply positioning and sizing
                    if (img.x !== undefined) imgEl.style.left = img.x + 'px';
                    if (img.y !== undefined) imgEl.style.top = img.y + 'px';
                    if (img.width) imgEl.style.width = img.width + 'px';
                    if (img.height) imgEl.style.height = img.height + 'px';
                    if (img.rotation) imgEl.style.transform = `rotate(${img.rotation}deg)`;
                    
                    // For fullspread, make image fill if no dimensions set
                    if (layout === 'fullspread' && !img.width && !img.height) {
                        imgEl.style.width = '100%';
                        imgEl.style.height = '100%';
                        imgEl.style.left = '0';
                        imgEl.style.top = '0';
                    }
                    
                    pageContent.appendChild(imgEl);
                }
            });
        }
    } else {
        // Render images in layout slots
        const layoutConfig = {
            'single': 1,
            'double': 2,
            'triple': 3,
            'quad': 4
        };
        
        const slotCount = layoutConfig[layout] || 1;
        const validImages = (content.images || []).filter(img => img && (img.url || img.cloudinary_url));
        
        for (let i = 0; i < slotCount; i++) {
            const slot = document.createElement('div');
            slot.className = 'image-slot';
            slot.style.position = 'relative';
            
            if (validImages[i]) {
                const img = validImages[i];
                const imgEl = document.createElement('img');
                const imageUrl = img.url || img.cloudinary_url;
                imgEl.src = imageUrl;
                imgEl.alt = `Page ${page.page_number} image ${i + 1}`;
                imgEl.style.width = '100%';
                imgEl.style.height = '100%';
                imgEl.style.objectFit = 'cover';
                
                // Apply rotation if present
                if (img.rotation) {
                    imgEl.style.transform = `rotate(${img.rotation}deg)`;
                }
                
                slot.appendChild(imgEl);
                slot.style.border = 'none';
                slot.style.background = 'transparent';
            }
            
            pageContent.appendChild(slot);
        }
    }
    
    // Add text elements with proper styling and positioning
    if (content.texts && content.texts.length > 0) {
        content.texts.forEach((textItem, index) => {
            if (textItem && textItem.text) {
                const textEl = document.createElement('div');
                textEl.className = 'text-element';
                textEl.textContent = textItem.text;
                textEl.style.color = textItem.color || '#000000';
                textEl.style.fontSize = (textItem.fontSize || 16) + 'px';
                textEl.style.fontFamily = textItem.fontFamily || 'Arial, sans-serif';
                textEl.style.position = 'absolute';
                textEl.style.left = (textItem.x || 0) + 'px';
                textEl.style.top = (textItem.y || 0) + 'px';
                textEl.style.zIndex = '10';
                
                // Ensure text doesn't overflow
                textEl.style.maxWidth = '90%';
                textEl.style.wordWrap = 'break-word';
                
                pageContent.appendChild(textEl);
            }
        });
    }
    
    pageDiv.appendChild(pageContent);
    return pageDiv;
}

// Navigation
document.getElementById('prevBtn').addEventListener('click', () => {
    if (currentPageIndex > 0) {
        currentPageIndex = Math.max(0, currentPageIndex - 2);
        renderPages();
    }
});

document.getElementById('nextBtn').addEventListener('click', () => {
    if (currentPageIndex < pages.length - 2) {
        currentPageIndex = Math.min(pages.length - 2, currentPageIndex + 2);
        renderPages();
    }
});

// Initialize
checkAuth();

