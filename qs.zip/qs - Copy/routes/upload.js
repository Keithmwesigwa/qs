const express = require('express');
const multer = require('multer');

module.exports = (pool, cloudinary) => {
  const router = express.Router();
  const auth = require('./auth')(pool);

  // All routes require authentication
  router.use(auth.authenticateToken);

  // Configure multer for memory storage
  const storage = multer.memoryStorage();
  const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: (req, file, cb) => {
      if (file.mimetype.startsWith('image/')) {
        cb(null, true);
      } else {
        cb(new Error('Only image files are allowed'));
      }
    }
  });

  // Upload single image
  router.post('/image', upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: 'No image file provided' });
      }

      // Upload to Cloudinary
      const result = await new Promise((resolve, reject) => {
        const uploadStream = cloudinary.uploader.upload_stream(
          {
            folder: 'photobook',
            resource_type: 'image'
          },
          (error, result) => {
            if (error) reject(error);
            else resolve(result);
          }
        );
        uploadStream.end(req.file.buffer);
      });

      // Save to database
      const [dbResult] = await pool.execute(
        'INSERT INTO images (user_id, cloudinary_id, cloudinary_url) VALUES (?, ?, ?)',
        [req.user.userId, result.public_id, result.secure_url]
      );

      res.json({
        message: 'Image uploaded successfully',
        image: {
          id: dbResult.insertId,
          url: result.secure_url,
          cloudinary_id: result.public_id
        }
      });
    } catch (error) {
      console.error('Upload error:', error);
      res.status(500).json({ message: 'Upload failed', error: error.message });
    }
  });

  // Upload multiple images
  router.post('/images', upload.array('images', 50), async (req, res) => {
    try {
      if (!req.files || req.files.length === 0) {
        return res.status(400).json({ message: 'No image files provided' });
      }

      const uploadPromises = req.files.map(file => {
        return new Promise((resolve, reject) => {
          const uploadStream = cloudinary.uploader.upload_stream(
            {
              folder: 'photobook',
              resource_type: 'image'
            },
            (error, result) => {
              if (error) reject(error);
              else resolve(result);
            }
          );
          uploadStream.end(file.buffer);
        });
      });

      const results = await Promise.all(uploadPromises);

      // Save to database
      const imageInserts = results.map(result => [
        req.user.userId,
        result.public_id,
        result.secure_url
      ]);

      const values = imageInserts.map(() => '(?, ?, ?)').join(', ');
      const flatValues = imageInserts.flat();

      await pool.execute(
        `INSERT INTO images (user_id, cloudinary_id, cloudinary_url) VALUES ${values}`,
        flatValues
      );

      const images = results.map(result => ({
        url: result.secure_url,
        cloudinary_id: result.public_id
      }));

      res.json({
        message: `${images.length} images uploaded successfully`,
        images
      });
    } catch (error) {
      console.error('Bulk upload error:', error);
      res.status(500).json({ message: 'Upload failed', error: error.message });
    }
  });

  // Get user's images
  router.get('/images', async (req, res) => {
    try {
      const [images] = await pool.execute(
        'SELECT * FROM images WHERE user_id = ? ORDER BY uploaded_at DESC',
        [req.user.userId]
      );

      res.json({ images });
    } catch (error) {
      console.error('Get images error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Delete image
  router.delete('/image/:id', async (req, res) => {
    try {
      // Get image info
      const [images] = await pool.execute(
        'SELECT cloudinary_id FROM images WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.userId]
      );

      if (images.length === 0) {
        return res.status(404).json({ message: 'Image not found' });
      }

      // Delete from Cloudinary
      await cloudinary.uploader.destroy(images[0].cloudinary_id);

      // Delete from database
      await pool.execute(
        'DELETE FROM images WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.userId]
      );

      res.json({ message: 'Image deleted successfully' });
    } catch (error) {
      console.error('Delete image error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  return router;
};

