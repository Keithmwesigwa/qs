const express = require('express');

module.exports = (pool, io) => {
  const router = express.Router();
  const auth = require('./auth')(pool);

  // All routes require authentication
  router.use(auth.authenticateToken);

  // Get all books for user
  router.get('/', async (req, res) => {
    try {
      const [books] = await pool.execute(
        'SELECT * FROM books WHERE user_id = ? ORDER BY updated_at DESC',
        [req.user.userId]
      );

      res.json({ books });
    } catch (error) {
      console.error('Get books error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Get single book with pages
  router.get('/:id', async (req, res) => {
    try {
      const [books] = await pool.execute(
        'SELECT * FROM books WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.userId]
      );

      if (books.length === 0) {
        return res.status(404).json({ message: 'Book not found' });
      }

      const book = books[0];

      // Get pages
      const [pages] = await pool.execute(
        'SELECT * FROM pages WHERE book_id = ? ORDER BY page_number',
        [book.id]
      );

      book.pages = pages;

      res.json({ book });
    } catch (error) {
      console.error('Get book error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Create new book
  router.post('/', async (req, res) => {
    try {
      const { title, template, mode, page_count } = req.body;

      if (!title || !template || !mode) {
        return res.status(400).json({ message: 'Title, template, and mode are required' });
      }

      const validTemplates = ['birthday', 'my bestie', 'my love', 'dear mum', 'wedding', 'dear dad', 'my sibling'];
      if (!validTemplates.includes(template)) {
        return res.status(400).json({ message: 'Invalid template' });
      }

      const pageCount = page_count === 50 ? 50 : 25; // Default to 25 if not 50

      const [result] = await pool.execute(
        'INSERT INTO books (user_id, title, template, mode, page_count) VALUES (?, ?, ?, ?, ?)',
        [req.user.userId, title, template, mode, pageCount]
      );

      const bookId = result.insertId;

      // Create pages based on page_count
      const defaultLayouts = ['single', 'double', 'triple', 'quad', 'single'];
      for (let i = 1; i <= pageCount; i++) {
        const layout = defaultLayouts[(i - 1) % defaultLayouts.length];
        await pool.execute(
          'INSERT INTO pages (book_id, page_number, layout_type, content) VALUES (?, ?, ?, ?)',
          [bookId, i, layout, JSON.stringify({ images: [], texts: [] })]
        );
      }

      // Emit real-time update
      io.to(`book-${bookId}`).emit('book-created', { bookId });

      res.status(201).json({ message: 'Book created', bookId });
    } catch (error) {
      console.error('Create book error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Update book
  router.put('/:id', async (req, res) => {
    try {
      const { title, status } = req.body;

      // Build update query dynamically based on what's provided
      const updates = [];
      const values = [];

      if (title !== undefined) {
        updates.push('title = ?');
        values.push(title);
      }

      if (status !== undefined) {
        updates.push('status = ?');
        values.push(status);
      }

      if (updates.length === 0) {
        return res.status(400).json({ message: 'No fields to update' });
      }

      values.push(req.params.id, req.user.userId);

      const [result] = await pool.execute(
        `UPDATE books SET ${updates.join(', ')} WHERE id = ? AND user_id = ?`,
        values
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Book not found' });
      }

      // Emit real-time update
      io.to(`book-${req.params.id}`).emit('book-updated', { bookId: req.params.id });

      res.json({ message: 'Book updated' });
    } catch (error) {
      console.error('Update book error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Delete book
  router.delete('/:id', async (req, res) => {
    try {
      const [result] = await pool.execute(
        'DELETE FROM books WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.userId]
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'Book not found' });
      }

      res.json({ message: 'Book deleted' });
    } catch (error) {
      console.error('Delete book error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  // Update page
  router.put('/:id/pages/:pageNumber', async (req, res) => {
    try {
      const { layout_type, content } = req.body;

      // Verify book ownership
      const [books] = await pool.execute(
        'SELECT id FROM books WHERE id = ? AND user_id = ?',
        [req.params.id, req.user.userId]
      );

      if (books.length === 0) {
        return res.status(404).json({ message: 'Book not found' });
      }

      // Update or insert page
      await pool.execute(
        `INSERT INTO pages (book_id, page_number, layout_type, content) 
         VALUES (?, ?, ?, ?) 
         ON DUPLICATE KEY UPDATE layout_type = ?, content = ?`,
        [
          req.params.id,
          req.params.pageNumber,
          layout_type,
          JSON.stringify(content),
          layout_type,
          JSON.stringify(content)
        ]
      );

      // Emit real-time update
      io.to(`book-${req.params.id}`).emit('page-updated', {
        bookId: req.params.id,
        pageNumber: req.params.pageNumber
      });

      res.json({ message: 'Page updated' });
    } catch (error) {
      console.error('Update page error:', error);
      res.status(500).json({ message: 'Server error' });
    }
  });

  return router;
};

