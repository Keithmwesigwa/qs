const express = require('express');
const PDFDocument = require('pdfkit');

module.exports = (pool, cloudinary) => {
  const router = express.Router();
  const auth = require('./auth')(pool);

  // All routes require authentication
  router.use(auth.authenticateToken);

  // Generate PDF for book
  router.post('/generate/:bookId', async (req, res) => {
    let doc = null;
    try {
      // Get book
      const [books] = await pool.execute(
        'SELECT * FROM books WHERE id = ? AND user_id = ?',
        [req.params.bookId, req.user.userId]
      );

      if (books.length === 0) {
        return res.status(404).json({ message: 'Book not found' });
      }

      const book = books[0];

      // Get pages
      const [pages] = await pool.execute(
        'SELECT * FROM pages WHERE book_id = ? ORDER BY page_number',
        [book.id]
      );

      // Create PDF
      doc = new PDFDocument({
        size: 'A4',
        margin: 0
      });

      // Don't pipe yet - we'll pipe after we've validated everything
      // This allows us to send proper error responses if something fails early

      // Helper function to convert hex to RGB
      function hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? {
          r: parseInt(result[1], 16),
          g: parseInt(result[2], 16),
          b: parseInt(result[3], 16)
        } : null;
      }

      // Helper function to get image URL
      function getImageUrl(img) {
        return img.cloudinary_url || img.url;
      }

      // Helper function to safely add image to PDF
      function addImageToPDF(doc, imageUrl, x, y, width, height) {
        try {
          if (!imageUrl) {
            console.warn('No image URL provided');
            return false;
          }

          // Validate URL format
          const urlString = String(imageUrl).trim();
          if (!urlString || (!urlString.startsWith('http://') && !urlString.startsWith('https://'))) {
            console.warn('Invalid image URL format:', urlString);
            return false;
          }

          // PDFKit's image method can handle URLs directly
          doc.image(urlString, x, y, {
            width: width,
            height: height,
            fit: [width, height]
          });
          return true;
        } catch (imgError) {
          console.error('Error adding image to PDF:', imgError.message);
          console.error('Image URL:', imageUrl);
          return false;
        }
      }

      // Add pages to PDF
      if (!pages || pages.length === 0) {
        // Add at least one blank page
        doc.addPage();
        doc.text('No pages in this book.', 50, 50);
        doc.end();
        return;
      }

      console.log(`Starting PDF generation for book ${book.id} with ${pages.length} pages`);

      for (const page of pages) {
        try {
          console.log(`Processing page ${page.page_number}...`);
          let content;
          try {
            content = typeof page.content === 'string' 
              ? JSON.parse(page.content) 
              : (page.content || {});
          } catch (parseError) {
            console.error(`Error parsing content for page ${page.page_number}:`, parseError.message);
            console.error('Parse error stack:', parseError.stack);
            content = {};
          }

          doc.addPage();
          console.log(`Added page ${page.page_number} to PDF`);

        // Add background color based on template
        const templateColors = {
          'birthday': '#FFE5E5',
          'my bestie': '#E5F3FF',
          'my love': '#FFE5F3',
          'dear mum': '#FFF5E5',
          'wedding': '#F0E5FF',
          'dear dad': '#E5FFE5',
          'my sibling': '#FFE5FF'
        };

        // Apply background color from page content if set, otherwise use template color
        if (content.backgroundColor) {
          const rgb = hexToRgb(content.backgroundColor);
          if (rgb) {
            doc.rect(0, 0, doc.page.width, doc.page.height)
               .fill([rgb.r / 255, rgb.g / 255, rgb.b / 255]);
          }
        } else {
          const defaultColor = templateColors[book.template] || '#FFFFFF';
          const rgb = hexToRgb(defaultColor);
          if (rgb) {
            doc.rect(0, 0, doc.page.width, doc.page.height)
               .fill([rgb.r / 255, rgb.g / 255, rgb.b / 255]);
          }
        }

        // Add images based on layout and positioning
        if (content.images && Array.isArray(content.images) && content.images.length > 0) {
          // Filter out null/undefined images and images without valid URLs
          const validImages = content.images.filter(img => {
            if (!img) return false;
            const url = getImageUrl(img);
            return url && typeof url === 'string' && url.trim().length > 0;
          });
          
          const layout = page.layout_type || 'single';
          const margin = 50;
          const topMargin = 50;
          const availableWidth = doc.page.width - (margin * 2);
          const availableHeight = doc.page.height - (topMargin * 2);

          // Check if any images have absolute positioning (x, y)
          const hasAbsolutePositioning = validImages.some(img => img.x !== undefined || img.y !== undefined);

          if (hasAbsolutePositioning || layout === 'fullspread') {
            // Render images with their absolute positions
            for (const img of validImages) {
              const imageUrl = getImageUrl(img);
              if (!imageUrl) continue;

              // Use provided coordinates or center if not set
              const x = (img.x !== undefined ? img.x : margin) + margin;
              const y = (img.y !== undefined ? img.y : topMargin) + topMargin;
              const width = img.width || availableWidth;
              const height = img.height || availableHeight;

              // For fullspread without positioning, fill the page
              if (layout === 'fullspread' && img.x === undefined && img.y === undefined) {
                addImageToPDF(doc, imageUrl, 0, 0, doc.page.width, doc.page.height);
              } else {
                addImageToPDF(doc, imageUrl, x, y, width, height);
              }
            }
          } else {
            // Render images in layout slots
            try {
              if (layout === 'single' && validImages.length >= 1) {
                addImageToPDF(doc, getImageUrl(validImages[0]), margin, topMargin, availableWidth, availableHeight);
              } else if (layout === 'double' && validImages.length >= 2) {
                const imgWidth = (availableWidth - 20) / 2;
                addImageToPDF(doc, getImageUrl(validImages[0]), margin, topMargin, imgWidth, availableHeight);
                addImageToPDF(doc, getImageUrl(validImages[1]), margin + imgWidth + 20, topMargin, imgWidth, availableHeight);
              } else if (layout === 'triple' && validImages.length >= 3) {
                const imgHeight = (availableHeight - 20) / 3;
                addImageToPDF(doc, getImageUrl(validImages[0]), margin, topMargin, availableWidth, imgHeight);
                addImageToPDF(doc, getImageUrl(validImages[1]), margin, topMargin + imgHeight + 10, availableWidth, imgHeight);
                addImageToPDF(doc, getImageUrl(validImages[2]), margin, topMargin + (imgHeight * 2) + 20, availableWidth, imgHeight);
              } else if (layout === 'quad' && validImages.length >= 4) {
                const imgWidth = (availableWidth - 20) / 2;
                const imgHeight = (availableHeight - 20) / 2;
                addImageToPDF(doc, getImageUrl(validImages[0]), margin, topMargin, imgWidth, imgHeight);
                addImageToPDF(doc, getImageUrl(validImages[1]), margin + imgWidth + 20, topMargin, imgWidth, imgHeight);
                addImageToPDF(doc, getImageUrl(validImages[2]), margin, topMargin + imgHeight + 20, imgWidth, imgHeight);
                addImageToPDF(doc, getImageUrl(validImages[3]), margin + imgWidth + 20, topMargin + imgHeight + 20, imgWidth, imgHeight);
              } else if (validImages.length > 0) {
                // Fallback: show first available image(s)
                const imgWidth = (availableWidth - 20) / 2;
                const imgHeight = (availableHeight - 20) / 2;
                for (let idx = 0; idx < Math.min(4, validImages.length); idx++) {
                  const img = validImages[idx];
                  const row = Math.floor(idx / 2);
                  const col = idx % 2;
                  addImageToPDF(doc, getImageUrl(img), margin + (col * (imgWidth + 20)), topMargin + (row * (imgHeight + 20)), imgWidth, imgHeight);
                }
              }
            } catch (imgError) {
              console.error('Error adding layout images to PDF:', imgError);
              console.error('Error details:', imgError.message, imgError.stack);
              // Continue with text even if images fail
            }
          }
        }

        // Add text
        if (content.texts && content.texts.length > 0) {
          content.texts.forEach(textItem => {
            try {
              if (textItem && textItem.text) {
                const textColor = textItem.color || '#000000';
                const rgb = hexToRgb(textColor);
                if (rgb) {
                  doc.fillColor([rgb.r / 255, rgb.g / 255, rgb.b / 255]);
                } else {
                  doc.fillColor('#000000');
                }
                doc.fontSize(textItem.fontSize || 16)
                   .text(textItem.text, textItem.x || 50, textItem.y || 50, {
                     width: doc.page.width - (textItem.x || 50) - 50,
                     align: 'left'
                   });
              }
            } catch (textError) {
              console.error('Error adding text to PDF:', textError);
              // Continue with other text elements
            }
          });
        }
        } catch (pageError) {
          console.error(`Error processing page ${page.page_number}:`, pageError);
          console.error('Page error message:', pageError.message);
          console.error('Page error stack:', pageError.stack);
          // Continue with next page even if current page fails
          // Add a blank page to maintain page count
          try {
            if (doc && !doc.ended) {
              doc.addPage();
              doc.text(`Error loading page ${page.page_number}`, 50, 50);
            }
          } catch (blankPageError) {
            console.error('Error adding blank page:', blankPageError);
          }
          continue;
        }
      }

      // End the document - this will trigger the stream to finish
      doc.end();

      console.log('PDF generation completed successfully');

      // Note: Status update removed from here - it's now handled in manual-mode.js after successful download

    } catch (error) {
      console.error('PDF generation error:', error);
      console.error('Error stack:', error.stack);
      
      // Make sure document is ended even on error
      if (doc && !doc.ended) {
        try {
          doc.end();
        } catch (endError) {
          console.error('Error ending PDF document:', endError);
        }
      }
      
      // Check if response headers have been sent (if doc.pipe was called)
      if (!res.headersSent) {
        return res.status(500).json({ 
          message: 'Server error', 
          error: error.message || 'Unknown error occurred during PDF generation'
        });
      } else {
        // Response already started, can't send JSON error - just log
        console.error('Cannot send error response - response stream already started');
      }
    }
  });

  return router;
};

