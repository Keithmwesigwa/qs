# PhotoBook - Dynamic Photo Book Creation App

A full-stack web application for creating custom photo books with smart and manual modes, similar to Pixory.com.

## Features

- **User Authentication**: Secure registration and login system
- **Two Creation Modes**:
  - **Smart Mode**: Upload images and let the algorithm automatically create a 25-page photo book
  - **Manual Mode**: Design each page yourself with custom layouts, images, and text
- **7 Beautiful Templates**: Birthday, My Bestie, My Love, Dear Mum, Wedding, Dear Dad, My Sibling
- **Image Management**: Upload and manage images using Cloudinary
- **PDF Generation**: Export completed books as PDF files
- **Real-time Updates**: Live updates using Socket.io

## Tech Stack

- **Backend**: Node.js, Express.js
- **Database**: MySQL
- **Image Storage**: Cloudinary
- **Authentication**: JWT (JSON Web Tokens)
- **Real-time**: Socket.io
- **PDF Generation**: PDFKit
- **Frontend**: HTML, CSS, JavaScript

## Installation

1. Install dependencies:
```bash
npm install
```

2. The database will be automatically created on first run. Make sure your MySQL credentials are correct in `server.js`.

3. Start the server:
```bash
npm start
```

For development with auto-reload:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:3000`

## Project Structure

```
├── server.js              # Main server file
├── routes/
│   ├── auth.js           # Authentication routes
│   ├── books.js          # Book management routes
│   ├── upload.js         # Image upload routes
│   └── pdf.js            # PDF generation routes
├── public/
│   ├── index.html        # Landing page
│   ├── login.html        # Login page
│   ├── register.html     # Registration page
│   ├── dashboard.html    # User dashboard
│   ├── smart-mode.html   # Smart mode editor
│   ├── manual-mode.html  # Manual mode editor
│   ├── css/              # Stylesheets
│   └── js/               # JavaScript files
└── package.json          # Dependencies
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `GET /api/auth/me` - Get current user info

### Books
- `GET /api/books` - Get all user's books
- `GET /api/books/:id` - Get single book
- `POST /api/books` - Create new book
- `PUT /api/books/:id` - Update book
- `DELETE /api/books/:id` - Delete book
- `PUT /api/books/:id/pages/:pageNumber` - Update page

### Upload
- `POST /api/upload/image` - Upload single image
- `POST /api/upload/images` - Upload multiple images
- `GET /api/upload/images` - Get user's images
- `DELETE /api/upload/image/:id` - Delete image

### PDF
- `POST /api/pdf/generate/:bookId` - Generate PDF for book

## Usage

1. **Register/Login**: Create an account or login
2. **Create Book**: Choose a template and mode (Smart or Manual)
3. **Smart Mode**: Upload images and let the algorithm create your book
4. **Manual Mode**: Design each page with custom layouts, add images and text
5. **Save & Export**: Save your work and generate PDF when ready

## Configuration

Cloudinary and MySQL credentials are configured in `server.js`. For production, move these to environment variables using a `.env` file.

## License

ISC

